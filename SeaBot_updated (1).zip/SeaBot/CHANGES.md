# SeaBot — Cập nhật 7 lệnh (giao diện mới, không Mongo)

## Đã đổi / thêm gì

| Lệnh | Trạng thái | Ghi chú |
|---|---|---|
| `info` | 🔄 Vẽ lại giao diện | Card kính mờ (glass), banner từ ảnh cover, avatar viền phát sáng |
| `scl` | 🔄 Vẽ lại giao diện | Backend (search/convert/upload/gửi) giữ nguyên, chỉ thay ảnh list & ảnh chi tiết |
| `welcome` | 🔄 Vẽ lại giao diện | Áp dụng cho join/leave/kick/admin, style đồng bộ toàn bộ |
| `bye` / `gbye` | ✨ Mới | Lệnh xem thử card tạm biệt ngay, không cần chờ ai rời nhóm |
| `nct` | ✨ Mới | Tìm & phát nhạc từ NhacCuaTui — có link nghe trực tiếp, không cần ffmpeg |
| `spotify` | ✨ Mới | Tìm metadata + bìa từ Spotify, **phát âm thanh qua SoundCloud** (Spotify không cho tải nhạc trực tiếp trừ tài khoản Premium) — có ghi chú rõ trong card để minh bạch |
| `topchat` | ✨ Mới | Bảng xếp hạng nhắn tin nhiều nhất trong nhóm, đếm bằng file `data/topchat.json` |

**Không dùng MongoDB ở đâu cả** — mọi lưu trữ đều là file JSON local (`data/topchat.json`,
các file setting sẵn có của SeaBot), chạy được trên điện thoại/Termux.

## File mới / đã sửa

- `modules/_glasscard.py` — **bộ khung vẽ dùng chung** (nền gradient mờ, khung kính,
  avatar viền, card nhạc...) cho tất cả 7 lệnh trên, để giao diện đồng bộ.
- `modules/info.py` — viết lại
- `modules/scl.py` — sửa 2 hàm vẽ ảnh (`draw_song_list_image`, `draw_song_detail_image`)
- `modules/nct.py` — file mới
- `modules/spotify.py` — file mới
- `modules/topchat.py` — file mới
- `modules/bye.py` — file mới
- `event/event.py` — viết lại hàm `create_event_image()` (dùng cho welcome/goodbye/kick/admin)
- `main.py` — thêm 3 dòng gọi `topchat.count_message(...)` trong `onMessage` để đếm tin nhắn

## Lưu ý khi chạy thật

- **`spotify`**: cần `open.spotify.com` và `api.spotify.com` truy cập được (không bị chặn mạng).
  Token là "guest token" công khai, không cần đăng ký tài khoản Spotify Developer.
- **`nct`**: cần `graph.nhaccuatui.com` truy cập được.
- **`topchat`**: cần chạy 1 thời gian để bot đếm được tin nhắn trước khi có dữ liệu hiển thị.
- Toàn bộ ảnh test đã chạy qua bằng dữ liệu giả lập (mock) để kiểm tra không lỗi cú pháp/layout,
  nhưng **chưa test được với dữ liệu thật** (avatar Zalo thật, API Spotify/NCT thật) vì mình không
  có kết nối tới các domain đó trong môi trường hiện tại. Nếu chạy lỗi, gửi mình traceback là
  mình soi tiếp ngay.

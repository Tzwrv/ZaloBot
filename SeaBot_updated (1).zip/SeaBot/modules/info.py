"""
info.py — the thong tin ca nhan (giao dien moi: glass card, dong bo voi
welcome/goodbye/scl/nct/spotify). Khong dung Mongo.
"""
import os
import time
from datetime import datetime
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
from zlapi.models import Message, ThreadType

from modules import _glasscard as gc

des = {
    'version': "2.0.0",
    'credits': "Seatzk",
    'description': "Xem thông tin người dùng (giao diện glass card mới)",
    'power': "Thành viên"
}

CACHE_DIR = "modules/cache"


def _fmt_ts(ts, default="Ẩn"):
    if not isinstance(ts, (int, float)) or ts <= 0:
        return default
    try:
        t = ts / 1000 if ts > 4_102_444_800 else ts
        return datetime.fromtimestamp(t).strftime("%H:%M %d/%m/%Y")
    except Exception:
        return default


def _resolve_target(message, message_object, author_id, client):
    mentions = getattr(message_object, "mentions", None) or []
    if mentions:
        return mentions[0].get("uid")
    parts = message.split()
    if len(parts) > 1:
        raw = parts[1]
        try:
            data = client.fetchPhoneNumber(raw, language="en")
            return data.get("uid", raw) if data else raw
        except Exception:
            return raw
    return author_id


def draw_info_card(user, target_id):
    W = 1000
    H = 720  # tinh du cho avatar + ten + panel info + panel bio
    avatar_img = gc.fetch_image(getattr(user, "avatar", None), None)
    cover_img = gc.fetch_image(getattr(user, "cover", None), (W, H))

    if cover_img is not None:
        bg = cover_img.resize((W, H), Image.LANCZOS).convert("RGBA")
        bg = ImageEnhance.Brightness(bg).enhance(0.55)
        bg = bg.filter(ImageFilter.GaussianBlur(22))
        dark = Image.new("RGBA", bg.size, (10, 12, 22, 120))
        bg.alpha_composite(dark)
        canvas = bg
        accent = (120, 170, 255)
    else:
        canvas = gc.draw_blob_background(W, H)
        accent = (120, 170, 255)

    draw = ImageDraw.Draw(canvas)

    gender_map = {0: "Nam", 1: "Nữ"}
    gender = gender_map.get(getattr(user, "gender", None), "Không rõ")
    biz = "Có" if getattr(user, "bizPkg", None) and getattr(user.bizPkg, "label", None) else "Không"

    name = getattr(user, "displayName", None) or getattr(user, "zaloName", None) or "Người dùng"
    status_text = getattr(user, "status", None) or "Chưa có tiểu sử."

    av_cy = 160
    gc.avatar_with_ring(canvas, avatar_img, W // 2, av_cy, 100, accent, ring_width=6)

    name_font = gc.get_font(gc.TITLE_FONT, 46)
    name = gc.fit_text(draw, name, name_font, W - 100)
    nw = draw.textbbox((0, 0), name, font=name_font)[2]
    draw.text(((W - nw) // 2, av_cy + 115), name, font=name_font, fill=(255, 255, 255))

    id_font = gc.get_font(gc.TEXT_FONT_MED, 22)
    id_text = f"ID: {getattr(user, 'userId', target_id)}"
    iw = draw.textbbox((0, 0), id_text, font=id_font)[2]
    draw.text(((W - iw) // 2, av_cy + 172), id_text, font=id_font, fill=(190, 195, 215))

    panel_top = av_cy + 220
    panel_h = 190
    gc.glass_panel(canvas, (40, panel_top, W - 40, panel_top + panel_h), radius=26, alpha=28, blur=20)

    items = [
        ("🚻 Giới tính", gender),
        ("🎂 Sinh nhật", _fmt_ts(getattr(user, "dob", None))),
        ("🗓️ Ngày tạo", _fmt_ts(getattr(user, "createdTs", None))),
        ("💡 Hoạt động", _fmt_ts(getattr(user, "lastActionTime", None))),
        ("💼 Business", biz),
        ("🌍 Global ID", str(getattr(user, "globalId", "")) or "Không có"),
    ]
    label_font = gc.get_font(gc.TEXT_FONT_MED, 22)
    val_font = gc.get_font(gc.TITLE_FONT, 24)
    col_w = (W - 80 - 40) // 2
    for idx, (label, val) in enumerate(items):
        col = idx % 2
        row = idx // 2
        x = 70 + col * (col_w + 40)
        y = panel_top + 22 + row * 56
        draw.text((x, y), label, font=label_font, fill=(175, 180, 200))
        val_s = gc.fit_text(draw, str(val), val_font, col_w)
        draw.text((x, y + 26), val_s, font=val_font, fill=(255, 255, 255))

    bio_top = panel_top + panel_h + 20
    bio_h = 90
    gc.glass_panel(canvas, (40, bio_top, W - 40, bio_top + bio_h), radius=22, alpha=22, blur=18)
    bio_font = gc.get_font(gc.TEXT_FONT_MED, 22)
    bio_s = gc.fit_text(draw, status_text, bio_font, W - 120)
    draw.text((70, bio_top + 32), bio_s, font=bio_font, fill=(225, 228, 240))

    H = bio_top + bio_h + 30
    return canvas.crop((0, 0, W, H)).convert("RGB")


def info(message, message_object, thread_id, thread_type, author_id, client):
    try:
        target_id = _resolve_target(message, message_object, author_id, client)
        user_info = client.fetchUserInfo(target_id)
        user = user_info.changed_profiles.get(target_id) if user_info else None

        if not user:
            client.send(Message(text="Không thể lấy thông tin người dùng này hoặc ID không hợp lệ."),
                         thread_id=thread_id, thread_type=thread_type)
            return

        img = draw_info_card(user, target_id)
        op = os.path.join(CACHE_DIR, f"info_{int(time.time()*1000)}.png")
        os.makedirs(CACHE_DIR, exist_ok=True)
        img.save(op, format="PNG")

        try:
            client.sendLocalImage(
                op, thread_id=thread_id, thread_type=thread_type,
                width=img.width, height=img.height, message=None, ttl=120000
            )
        finally:
            if os.path.exists(op):
                os.remove(op)

    except Exception as e:
        client.send(Message(text=f"Lỗi khi lấy thông tin: {e}"), thread_id=thread_id, thread_type=thread_type)


def PTA():
    return {'info': info}

import sys
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from config import PREFIX

des = {
    'version': '1.0.0',
    'credits': "Seatzk",
    'description': 'Xem toàn bộ danh sách lệnh có sẵn của bot theo từng trang.',
    'power': 'Tất cả mọi người'
}

ITEMS_PER_PAGE = 8

GREEN = "#22c55e"
YELLOW = "#eab308"
RED = "#e53935"
FONT_SIZE = "14"


def _get_all_commands(client):
    items = []
    pta = getattr(client.command_handler, 'PTA', {}) or {}
    for cmd_name, handler in pta.items():
        mod_name = getattr(handler, '__module__', None)
        mod = sys.modules.get(mod_name)
        desc = "Không có mô tả."
        if mod is not None and hasattr(mod, 'des') and isinstance(mod.des, dict):
            desc = mod.des.get('description', desc)
        items.append((cmd_name, desc))
    items.sort(key=lambda x: x[0])
    return items


def _reply(client, message_object, thread_id, thread_type, text, styles):
    client.replyMessage(
        Message(text=text, style=MultiMsgStyle(styles)),
        message_object, thread_id, thread_type, ttl=90000
    )


def handle_command_list(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    arg = parts[1] if len(parts) > 1 else ""

    prefix = getattr(client.command_handler, 'current_prefix', PREFIX)

    # ==========================
    # ,command load / ,cmd load
    # ==========================
    if arg.lower() == "load":
        pta = getattr(client.command_handler, 'PTA', {}) or {}
        total = len(pta)
        full_text = f"📦 Số Lệnh Sở Hữu : {total}"

        styles = [
            MessageStyle(offset=0, length=len(full_text), style="font", size=FONT_SIZE, auto_format=False),
            MessageStyle(offset=0, length=len(full_text), style="color", color=RED, auto_format=False),
            MessageStyle(offset=0, length=len(full_text), style="bold", auto_format=False),
        ]
        _reply(client, message_object, thread_id, thread_type, full_text, styles)
        return

    # ==========================
    # ,command <trang> / ,cmd <trang>
    # ==========================
    commands = _get_all_commands(client)
    if not commands:
        client.replyMessage(Message(text="⚠️ Không có lệnh nào được load."), message_object, thread_id, thread_type)
        return

    total_pages = (len(commands) + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE
    page = int(arg) if arg.isdigit() else 1
    page = max(1, min(page, total_pages))

    start = (page - 1) * ITEMS_PER_PAGE
    end = min(len(commands), start + ITEMS_PER_PAGE)

    header = f"📋 DANH SÁCH LỆNH — Trang {page}/{total_pages}\n\n"
    footer = f"\nGõ {prefix}command <số trang> để xem trang khác (VD: {prefix}cmd 2).\nGõ {prefix}cmd load để xem tổng số lệnh."

    body_parts = []
    styles = []
    cursor = len(header)

    for cmd_name, desc in commands[start:end]:
        name_text = f"{prefix}{cmd_name}"
        styles.append(MessageStyle(offset=cursor, length=len(name_text), style="color", color=GREEN, auto_format=False))
        styles.append(MessageStyle(offset=cursor, length=len(name_text), style="bold", auto_format=False))
        cursor += len(name_text)
        body_parts.append(name_text)

        body_parts.append("\n")
        cursor += 1

        desc_text = f"↳ {desc}"
        styles.append(MessageStyle(offset=cursor, length=len(desc_text), style="color", color=YELLOW, auto_format=False))
        cursor += len(desc_text)
        body_parts.append(desc_text)

        body_parts.append("\n\n")
        cursor += 2

    full_text = header + "".join(body_parts) + footer

    # Font size 14 áp dụng cho toàn bộ tin nhắn
    styles.insert(0, MessageStyle(offset=0, length=len(full_text), style="font", size=FONT_SIZE, auto_format=False))

    _reply(client, message_object, thread_id, thread_type, full_text, styles)


def PTA():
    return {
        "command": handle_command_list,
        "cmd": handle_command_list,
    }

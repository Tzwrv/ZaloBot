"""
_glasscard.py — bo ve dung chung (gradient blob + kinh mo/glassmorphism)
Dung lai cho: welcome/goodbye (event.py), info, scl, nct, spotify.

Khong phu thuoc Mongo / dto.index / this-object. Chi can requests + Pillow.
Font lay tu modules/cache/font (local, khong tai mang -> chay duoc tren dt/Termux).
"""
import os
import random
import requests
from io import BytesIO
from PIL import Image, ImageDraw, ImageFilter, ImageFont

FONT_DIR = os.path.join(os.path.dirname(__file__), "cache", "font")

_FONT_CACHE = {}


def get_font(name, size):
    key = (name, size)
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    path = os.path.join(FONT_DIR, name)
    try:
        f = ImageFont.truetype(path, size)
    except Exception:
        try:
            f = ImageFont.truetype(os.path.join(FONT_DIR, "arial.ttf"), size)
        except Exception:
            f = ImageFont.load_default()
    _FONT_CACHE[key] = f
    return f


TITLE_FONT = "BeVietnamPro-Bold.ttf"
TEXT_FONT = "BeVietnamPro-SemiBold.ttf"
TEXT_FONT_MED = "BeVietnamPro-Medium.ttf"


def fetch_image(url, size=None, timeout=10):
    """Tai anh tu URL, tra ve RGBA hoac None neu loi."""
    if not url or not isinstance(url, str) or not url.strip():
        return None
    try:
        r = requests.get(url.strip(), timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200 and r.content:
            im = Image.open(BytesIO(r.content)).convert("RGBA")
            if size:
                im = im.resize(size, Image.LANCZOS)
            return im
    except Exception:
        pass
    return None


def rounded_mask(w, h, r, aa=4):
    mw, mh = w * aa, h * aa
    rr = int(min(r, w // 2, h // 2) * aa)
    m = Image.new("L", (mw, mh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), rr, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def circle_mask(size, aa=4):
    m = Image.new("L", (size * aa, size * aa), 0)
    ImageDraw.Draw(m).ellipse((0, 0, size * aa, size * aa), fill=255)
    return m.resize((size, size), Image.LANCZOS)


def draw_cover(dst, src, x, y, w, h):
    """Paste src vao vung (x,y,w,h) theo kieu 'cover' (giu ty le, crop du)."""
    if src is None:
        return
    scale = max(w / src.width, h / src.height)
    dw, dh = int(src.width * scale), int(src.height * scale)
    dx = x + (w - dw) // 2
    dy = y + (h - dh) // 2
    resized = src.resize((dw, dh), Image.LANCZOS)
    layer = Image.new("RGBA", dst.size, (0, 0, 0, 0))
    layer.paste(resized, (dx, dy))
    mask = Image.new("L", dst.size, 0)
    ImageDraw.Draw(mask).rectangle((x, y, x + w, y + h), fill=255)
    dst.paste(layer, (0, 0), Image.composite(layer.split()[-1] if layer.mode == "RGBA" else mask, Image.new("L", dst.size, 0), mask))


def rand_palette():
    """Nen gradient toi + mau cham mau (blob) ngau nhien, tone dep."""
    tops = [
        (10, 14, 42), (22, 12, 50), (12, 28, 55), (35, 15, 25),
        (10, 25, 18), (40, 18, 12), (18, 12, 42), (8, 35, 28),
    ]
    top = random.choice(tops)
    bot = tuple(max(0, c - 10) for c in top)
    accents = [
        (80, 140, 255), (160, 90, 255), (70, 180, 210),
        (140, 70, 255), (255, 160, 60), (60, 210, 180),
        (255, 100, 130), (255, 180, 120),
    ]
    blobs = [(*random.choice(accents), random.randint(30, 60)) for _ in range(8)]
    return top, bot, blobs


def draw_blob_background(w, h, accent_override=None):
    """Ve nen gradient + cac vung mau mo (glow blob). Tra ve Image RGBA."""
    top, bot, blobs = rand_palette()
    if accent_override:
        blobs = [(*accent_override, random.randint(30, 55)) for _ in range(8)]

    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / max(1, h)
        d.line((0, y, w, y), fill=(
            int(top[0] * (1 - t) + bot[0] * t),
            int(top[1] * (1 - t) + bot[1] * t),
            int(top[2] * (1 - t) + bot[2] * t),
        ))
    img = img.convert("RGBA")

    layer = Image.new("RGBA", img.size)
    ld = ImageDraw.Draw(layer)
    for _ in range(10):
        rad = random.randint(int(h * 0.35), int(h * 0.9))
        x = random.randint(-rad // 2, w)
        y = random.randint(-rad // 2, h)
        c = random.choice(blobs)
        ld.ellipse((x, y, x + rad, y + rad), fill=c)
    img.alpha_composite(layer.filter(ImageFilter.GaussianBlur(int(h * 0.35))))

    # vien kinh mo nhe quanh canvas
    border = Image.new("RGBA", img.size, (0, 0, 0, 0))
    bd = ImageDraw.Draw(border)
    pad = int(h * 0.03)
    bd.rounded_rectangle((pad, pad, w - pad, h - pad), int(h * 0.06),
                          fill=(255, 255, 255, 6), outline=(255, 255, 255, 14), width=1)
    img.alpha_composite(border)
    return img


def glass_panel(canvas, box, radius=24, alpha=26, blur=18):
    """Ve 1 khung 'kinh mo' (blur nen phia sau + lop trang mo) len canvas RGBA."""
    x1, y1, x2, y2 = [int(v) for v in box]
    bw, bh = max(1, x2 - x1), max(1, y2 - y1)
    crop = canvas.crop((x1, y1, x2, y2)).filter(ImageFilter.GaussianBlur(blur))
    layer = Image.alpha_composite(crop, Image.new("RGBA", (bw, bh), (255, 255, 255, alpha)))
    mask = rounded_mask(bw, bh, radius)
    canvas.paste(layer, (x1, y1), mask)


def avatar_with_ring(canvas, av_img, cx, cy, radius, ring_color, ring_width=6):
    """Ve avatar tron co vien mau (glow nhe) tai tam (cx,cy)."""
    size = radius * 2
    glow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    for i in range(10):
        a = max(1, 18 - i * 2)
        rr = radius + ring_width + i * 4
        gd.ellipse((cx - rr, cy - rr, cx + rr, cy + rr), fill=(*ring_color[:3], a))
    canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(int(radius * 0.18))))

    ring = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    rd.ellipse((cx - radius - ring_width, cy - radius - ring_width,
                cx + radius + ring_width, cy + radius + ring_width), fill=(*ring_color[:3], 255))
    canvas.alpha_composite(ring)

    if av_img is not None:
        av = av_img.resize((size, size), Image.LANCZOS)
        mask = circle_mask(size)
        canvas.paste(av, (cx - radius, cy - radius), mask)
    else:
        blank = Image.new("RGBA", (size, size), (40, 44, 60, 255))
        mask = circle_mask(size)
        canvas.paste(blank, (cx - radius, cy - radius), mask)


def fit_text(draw, text, font, max_w):
    t = str(text or "")
    if not t:
        return ""
    while t and draw.textbbox((0, 0), t, font=font)[2] > max_w:
        t = t[:-1]
    if len(t) < len(str(text or "")):
        while t and draw.textbbox((0, 0), t + "...", font=font)[2] > max_w:
            t = t[:-1]
        t += "..."
    return t


def autosave_tmp(img, quality=90):
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
        img.convert("RGB").save(tf.name, "JPEG", quality=quality)
        return tf.name


# ---------------------------------------------------------------------------
# The vien nhac dung chung cho scl / nct / spotify
# songs: list of tuple (link, title, cover_url, duration_str, play, like, cmt, artist)
# ---------------------------------------------------------------------------

def draw_music_list_card(songs, provider_label, accent):
    if not songs:
        return None
    from concurrent.futures import ThreadPoolExecutor

    W, H = 1080, 480
    canvas = draw_blob_background(W, H, accent_override=accent)
    draw = ImageDraw.Draw(canvas)

    f_title_l = get_font(TITLE_FONT, 25)
    f_artist_l = get_font(TEXT_FONT_MED, 19)
    f_title_s = get_font(TEXT_FONT, 19)
    f_artist_s = get_font(TEXT_FONT_MED, 15)
    f_num = get_font(TEXT_FONT, 16)
    f_badge = get_font(TEXT_FONT, 14)

    cover_urls = [s[2] for s in songs]
    with ThreadPoolExecutor(max_workers=11) as ex:
        imgs = list(ex.map(lambda u: fetch_image(u, None), cover_urls))

    # hero (bai dau tien)
    link, title, _, duration, play, like, cmt, artist = songs[0]
    glass_panel(canvas, (20, 20, 340, 460), radius=22, alpha=24, blur=16)
    c_img = imgs[0]
    if c_img:
        c_img = c_img.resize((280, 280), Image.LANCZOS)
        mask = rounded_mask(280, 280, 18)
        canvas.paste(c_img, (40, 40), mask)
    t_str = fit_text(draw, title, f_title_l, 280)
    draw.text((40, 340), t_str, font=f_title_l, fill=(255, 255, 255))
    a_str = fit_text(draw, artist, f_artist_l, 280)
    draw.text((40, 375), a_str, font=f_artist_l, fill=(200, 202, 220))

    bw = f_badge.getlength(provider_label) + 24
    draw.rounded_rectangle([40, 415, 40 + bw, 445], radius=14, fill=(*accent, 255))
    draw.text((52, 422), provider_label, font=f_badge, fill=(15, 15, 20))

    for idx, s in enumerate(songs[1:11]):
        link, title, _, duration, play, like, cmt, artist = s
        col, row = idx // 5, idx % 5
        item_x = 360 + col * 360
        item_y = 20 + row * 91
        glass_panel(canvas, (item_x, item_y, item_x + 340, item_y + 75), radius=16, alpha=20, blur=12)

        c_img = imgs[idx + 1]
        if c_img:
            c_img = c_img.resize((55, 55), Image.LANCZOS)
            mask = rounded_mask(55, 55, 12)
            canvas.paste(c_img, (item_x + 10, item_y + 10), mask)

        t_str = fit_text(draw, title, f_title_s, 220)
        draw.text((item_x + 75, item_y + 15), t_str, font=f_title_s, fill=(255, 255, 255))
        info_str = f"{artist} | {duration}" if duration else artist
        info_str = fit_text(draw, info_str, f_artist_s, 220)
        draw.text((item_x + 75, item_y + 40), info_str, font=f_artist_s, fill=(190, 192, 210))

        num_str = str(idx + 2)
        nw = f_num.getlength(num_str)
        draw.text((item_x + 325 - nw, item_y + 28), num_str, font=f_num, fill=accent)

    return autosave_tmp(canvas)


def draw_music_detail_card(title, artist, duration, playback_count, like_count, comment_count,
                            cover, requester_avatar_url, provider_label, accent, extra_note=None):
    W, H = 760, 260
    cover_img = fetch_image(cover, None)
    avatar_img = fetch_image(requester_avatar_url, None)

    if cover_img is not None:
        bg = cover_img.resize((int(W / 4), int(H / 4)), Image.LANCZOS).resize((W, H), Image.LANCZOS)
        bg = bg.convert("RGBA").filter(ImageFilter.GaussianBlur(2))
        overlay = Image.new("RGBA", (W, H), (10, 12, 22, 190))
        bg.alpha_composite(overlay)
        canvas = bg
    else:
        canvas = draw_blob_background(W, H, accent_override=accent)
    draw = ImageDraw.Draw(canvas)

    cx, cy, cr = 130, H // 2, 85
    avatar_with_ring(canvas, cover_img, cx, cy, cr, accent, ring_width=5)

    f_title = get_font(TITLE_FONT, 27)
    f_title_s = get_font(TITLE_FONT, 22)
    f_info = get_font(TEXT_FONT_MED, 18)
    f_badge = get_font(TEXT_FONT, 13)

    tx = 250
    max_w = W - tx - 30
    t_str = fit_text(draw, title, f_title, max_w)
    ty = 34
    draw.text((tx, ty), t_str, font=f_title, fill=(255, 255, 255))
    ty += 40
    draw.text((tx, ty), fit_text(draw, f"Nghệ sĩ: {artist}", f_info, max_w), font=f_info, fill=(*accent, 255))
    ty += 30

    def fmt(n):
        try:
            n = int(n)
        except Exception:
            return str(n)
        if n >= 1_000_000:
            return f"{n/1_000_000:.1f}M".replace(".0", "")
        if n >= 1000:
            return f"{n/1000:.1f}K".replace(".0", "")
        return str(n)

    stats = f"🎧 {fmt(playback_count)}   ❤️ {fmt(like_count)}   💬 {fmt(comment_count)}   ⏱ {duration}"
    draw.text((tx, ty), stats, font=f_info, fill=(220, 222, 235))
    ty += 34

    bw = f_badge.getlength(provider_label) + 22
    draw.rounded_rectangle([tx, ty, tx + bw, ty + 26], radius=13, fill=(*accent, 255))
    draw.text((tx + 11, ty + 5), provider_label, font=f_badge, fill=(15, 15, 20))

    if extra_note:
        note_font = get_font(TEXT_FONT_MED, 14)
        draw.text((tx, H - 30), extra_note, font=note_font, fill=(170, 175, 195))

    if avatar_img is not None:
        avatar_with_ring(canvas, avatar_img, W - 55, H - 55, 30, accent, ring_width=3)

    return autosave_tmp(canvas)

"""
bye.py — xem thu (preview) card tam biet/duoi nhom voi giao dien moi (glass card),
khong can doi ai roi nhom that de test. Dung chung ham ve voi event.py.

Lenh:
  bye            -> xem thu card "roi nhom" (tu ban)
  bye @mention    -> xem thu card cho nguoi duoc tag
"""
import os
import time
from PIL import Image
from zlapi.models import Message, ThreadType

des = {
    'version': "1.0.0",
    'credits': "Seatzk",
    'description': "Xem thử card tạm biệt (goodbye) kiểu mới, không cần chờ ai rời nhóm",
    'power': "Thành viên"
}

CACHE_DIR = "modules/cache"


def _get_profile(client, uid):
    try:
        info = client.fetchUserInfo(uid)
        d = {}
        if info and hasattr(info, "changed_profiles"):
            d = info.changed_profiles.get(str(uid), {})
        return {
            "name": d.get("zaloName") or d.get("displayName") or "Thành viên",
            "avatar": d.get("avatar") or "",
            "cover": d.get("cover") or "",
        }
    except Exception:
        return {"name": "Thành viên", "avatar": "", "cover": ""}


def handle_bye_command(message, message_object, thread_id, thread_type, author_id, client):
    from event.event import create_event_image

    target_id = author_id
    mentions = getattr(message_object, "mentions", None) or []
    if mentions:
        try:
            target_id = mentions[0].get("uid") or author_id
        except Exception:
            pass

    profile = _get_profile(client, target_id)

    group_name = "Nhóm"
    try:
        gi = client.fetchGroupInfo(thread_id)
        group_name = gi.gridInfoMap.get(thread_id, {}).get("name", "Nhóm")
    except Exception:
        pass

    message_info = {
        "title": "XEM THỬ (PREVIEW)",
        "userName": profile["name"],
        "subtitle": f"Vừa rời khỏi {group_name}",
        "author": "Đây là bản xem thử, không phải sự kiện thật",
    }

    img = create_event_image(profile, message_info, "goodbye")
    op = os.path.join(CACHE_DIR, f"bye_preview_{int(time.time()*1000)}.png")
    os.makedirs(CACHE_DIR, exist_ok=True)
    img.save(op, format="PNG")

    try:
        client.sendLocalImage(
            op, thread_id=thread_id, thread_type=thread_type,
            width=img.width, height=img.height,
            message=Message(text="Đây là giao diện goodbye mới, chỉ để xem thử 👋"),
            ttl=120000
        )
    finally:
        if os.path.exists(op):
            os.remove(op)


def PTA():
    return {
        'bye': handle_bye_command,
        'gbye': handle_bye_command,
    }

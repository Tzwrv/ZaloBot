"""
nct.py — tim va gui nhac tu NhacCuaTui (khong Mongo, khong can API key).
NCT tra ve link CDN nghe truc tiep -> gui thang bang sendRemoteVoice,
khong can ffmpeg/convert nhu SoundCloud.
"""
import os
import re
import time
import requests
from concurrent.futures import ThreadPoolExecutor
from zlapi.models import Message, ThreadType, Mention

from modules import _glasscard as gc
from modules.scl import get_styled_msg, get_user_name, get_user_avatar, force_delete_msg, delete_file

des = {
    'version': "1.0.0",
    'credits': "Seatzk",
    'description': "Tìm và gửi nhạc từ NhacCuaTui",
    'power': "Thành viên"
}

SEARCH_TIMEOUT = 120
NCT_API_BASE = "https://graph.nhaccuatui.com/api/v1"
_session = requests.Session()
_session.headers.update({"User-Agent": "Mozilla/5.0", "Accept": "application/json,*/*"})

if not hasattr(get_user_name, "_nct_states"):
    pass
_user_states = {}


def _get(path, params=None):
    r = _session.get(f"{NCT_API_BASE}{path}", params=params or {}, timeout=15)
    r.raise_for_status()
    return r.json()


def _pick_by_type(items, t, field):
    for i in items or []:
        if str(i.get("type")) == str(t):
            return (i.get(field) or "").strip()
    return ""


def search_songs_nct(query, limit=10):
    j = _get("/search/song", params={
        "keyword": query, "pageindex": 1, "pagesize": limit,
        "correct": "false", "timestamp": int(time.time() * 1000)
    })
    songs = ((j or {}).get("data") or {}).get("songs") or []
    out = []
    for x in songs:
        streams = x.get("streamURL") or []
        duration = int(x.get("duration") or 0)
        mm, ss = divmod(duration, 60)
        out.append((
            x.get("key"),                      # link/key dung de resolve
            x.get("name") or "Không rõ",        # title
            x.get("image") or "",               # cover
            f"{mm}:{ss:02d}" if duration else "",  # duration_str
            int(x.get("viewed") or 0),          # plays
            0, 0,                               # likes, comments (NCT khong co)
            x.get("artistName") or "",          # artist
        ))
    return out


def resolve_song(song_key):
    j = _get(f"/song/detail/{song_key}", params={
        "isDailyMix": "false", "key": song_key, "timestamp": int(time.time() * 1000)
    })
    d = (j or {}).get("data") or {}
    if not d:
        raise RuntimeError("Không lấy được chi tiết bài hát từ NhacCuaTui.")
    streams = d.get("streamURL") or []
    downloads = d.get("qualityDownload") or []
    url = (_pick_by_type(streams, "320", "stream") or _pick_by_type(streams, 128, "stream")
           or _pick_by_type(downloads, "320", "download") or _pick_by_type(downloads, 128, "download"))
    return {
        "title": d.get("name") or "Không rõ",
        "artist": d.get("artistName") or "",
        "cover": d.get("image") or "",
        "duration_ms": int(d.get("duration") or 0) * 1000,
        "plays": int(d.get("viewed") or 0),
        "url": url,
    }


def _get_filesize(url):
    try:
        r = _session.head(url, timeout=10, allow_redirects=True)
        return int(r.headers.get("content-length", 0)) or None
    except Exception:
        return None


def handle_nct_command(message_text, message_object, thread_id, thread_type, author_id, client):
    name = get_user_name(client, author_id)
    parts = message_text.strip().split()
    query_or_choice = " ".join(parts[1:]) if len(parts) > 1 else ""
    if not query_or_choice and author_id in _user_states:
        m = re.search(r"\b(\d+)\b", message_text.strip())
        if m:
            query_or_choice = m.group(1)

    try:
        if query_or_choice.isdigit() and author_id in _user_states:
            state = _user_states[author_id]
            if time.time() - state['time_of_search'] > SEARCH_TIMEOUT:
                del _user_states[author_id]
                return

            songs = state['songs']
            index = int(query_or_choice) - 1
            if not (0 <= index < len(songs)):
                client.replyMessage(get_styled_msg(f"@{name} lựa chọn không hợp lệ.", author_id, name),
                                     message_object, thread_id, thread_type, ttl=60000)
                return

            song_key, title, cover, duration_str, plays, likes, cmts, artist = songs[index]
            send_response_obj = state.get('send_response')
            del _user_states[author_id]
            force_delete_msg(client, send_response_obj, thread_id)

            wait_content = f"@{name} Đợi xíu, đang lấy nhạc từ NhacCuaTui...\n\n🎵: {title}"
            wait_msg = client.replyMessage(get_styled_msg(wait_content, author_id, name),
                                            message_object, thread_id, thread_type, ttl=120000)

            detail = resolve_song(song_key)
            if not detail.get("url"):
                raise Exception("Bài này không có link nghe trực tiếp (có thể bị giới hạn bản quyền).")

            requester_avatar = get_user_avatar(client, author_id)
            duration_str = duration_str or f"{detail['duration_ms']//60000}:{(detail['duration_ms']//1000)%60:02d}"

            detail_image_path = gc.draw_music_detail_card(
                detail["title"], detail["artist"], duration_str,
                detail["plays"], likes, cmts, detail["cover"], requester_avatar,
                "NhacCuaTui", (230, 30, 60)
            )

            content = f"@{name}\n> From NhacCuaTui <\nNhạc Bạn Chọn Đây!!"
            client.send(get_styled_msg(content, author_id, name), thread_id=thread_id, thread_type=thread_type, ttl=210000)
            force_delete_msg(client, wait_msg, thread_id)

            from PIL import Image
            with Image.open(detail_image_path) as im:
                w, h = im.size
            client.sendLocalImage(detail_image_path, thread_id=thread_id, thread_type=thread_type,
                                   width=w, height=h, message=None, ttl=210000)
            delete_file(detail_image_path)

            file_size = _get_filesize(detail["url"])
            client.sendRemoteVoice(detail["url"], thread_id=thread_id, thread_type=thread_type,
                                    fileSize=file_size, ttl=1800000)
            return

        if not query_or_choice:
            client.replyMessage(get_styled_msg(f"@{name} Vui lòng nhập tên bài hát.", author_id, name),
                                 message_object, thread_id, thread_type, ttl=60000)
            return

        songs = search_songs_nct(query_or_choice)
        if not songs:
            client.replyMessage(get_styled_msg(f"@{name} Không tìm thấy kết quả cho '{query_or_choice}'.", author_id, name),
                                 message_object, thread_id, thread_type, ttl=60000)
            return

        img_path = gc.draw_music_list_card(songs, "NhacCuaTui", (230, 30, 60))
        from PIL import Image
        with Image.open(img_path) as im:
            w, h = im.size

        send_response = client.sendLocalImage(
            img_path, thread_id=thread_id, thread_type=thread_type, width=w, height=h,
            message=get_styled_msg(f"@{name} hãy trả lời tin nhắn này bằng số index để tải", author_id, name),
            ttl=120000
        )
        _user_states[author_id] = {'songs': songs, 'time_of_search': time.time(), 'send_response': send_response}
        delete_file(img_path)

    except Exception as e:
        client.replyMessage(get_styled_msg(f"@{name} đã xảy ra lỗi: {e}", author_id, name),
                             message_object, thread_id, thread_type, ttl=60000)


def PTA():
    return {'nct': handle_nct_command}

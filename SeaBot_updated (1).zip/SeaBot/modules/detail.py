
import os
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import requests
import base64
import emoji
import concurrent.futures
import time
import psutil
import platform
import json
import tempfile
import sys
from zlapi.models import Message

des = {'version': "1.6.0", 'credits': "Seatzk", 'description': "Bot Detail", 'power': "User"}
start_time = time.time()
start_ram_used = psutil.virtual_memory().used
FONT_PATH = "modules/cache/font/BeVietnamPro-Bold.ttf"
EMOJI_FONT_PATH = "modules/cache/font/NotoEmoji-Bold.ttf"

AUTO_APPROVE_PATH = "data/auto_approve_settings.json"
ANTIALL_PATH = "data/antiall_settings.json"
ANTIPHOTO_PATH = "data/antiphoto_settings.json"
ANTIRICON_PATH = "data/antiricon_settings.json"
ANTIFILE_PATH = "data/antifile_settings.json"
ANTIVIDEO_PATH = "data/antivideo_settings.json"
ANTISTICKER_PATH = "data/antisticker_settings.json"
AUTODOWNLOAD_PATH = "modules/cache/autodownload_groups.json"

def create_dynamic_bg_menu(W, H):
    """Tạo background gradient với blur effect"""
    base = Image.new('RGBA', (W, H), (15, 15, 20, 255))
    top = Image.new('RGBA', (W, H), (30, 30, 45, 255))
    mask = Image.new('L', (W, H))
    for x in range(W):
        for y in range(H):
            mask.putpixel((x, y), int(255 * (x / W)))
    bg = Image.composite(top, base, mask)
    overlay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    d.ellipse([W//4-200, H//4-200, W//4+200, H//4+200], fill=(60, 60, 100, 40))
    d.ellipse([W*3//4-150, H*3//4-150, W*3//4+150, H*3//4+150], fill=(100, 60, 80, 30))
    bg = Image.alpha_composite(bg, overlay)
    bg = bg.filter(ImageFilter.GaussianBlur(50))
    return bg

def get_font(size):
    try: 
        return ImageFont.truetype(FONT_PATH, size)
    except IOError: 
        return ImageFont.load_default()

def get_emoji_font(size):
    try: 
        return ImageFont.truetype(EMOJI_FONT_PATH, size)
    except IOError: 
        return get_font(size)

def calculate_text_width(text, font, emoji_font):
    return sum(emoji_font.getlength(c) if emoji.emoji_count(c) else font.getlength(c) for c in text)

def draw_rainbow_border(draw, x, y, size, width=4):
    """Vẽ viền bảy màu (rainbow) quanh avatar"""
    import math
    
    # 7 màu cầu vồng
    rainbow_colors = [
        (255, 0, 0),      # Đỏ
        (255, 127, 0),    # Cam
        (255, 255, 0),    # Vàng
        (0, 255, 0),      # Xanh lá
        (0, 0, 255),      # Xanh dương
        (75, 0, 130),     # Chàm
        (148, 0, 211)     # Tím
    ]
    
    # Vẽ nhiều vòng tròn đồng tâm với màu khác nhau
    num_layers = len(rainbow_colors)
    layer_width = width / num_layers
    
    for i, color in enumerate(rainbow_colors):
        offset = i * layer_width
        draw.ellipse(
            [x - offset, y - offset, x + size + offset, y + size + offset],
            outline=color,
            width=max(1, int(layer_width))
        )

def draw_item(draw, icon, name, enabled, position, font, emoji_font, value_font, box_size):
    """Vẽ một feature card"""
    x, y = position
    box_w, box_h = box_size
    radius = 24
    fill = (35, 35, 45, 180) 
    outline = (255, 255, 255, 40)
    draw.rounded_rectangle([x, y, x+box_w, y+box_h], radius, fill=fill, outline=outline, width=1)
    draw.line([x + 20, y + 40, x + box_w - 20, y + 40], fill=(255, 255, 255, 30), width=1)
    
    # Icon
    icon_font = emoji_font
    icon_x = x + 30
    icon_y = y + 5
    draw.text((icon_x, icon_y), icon, font=icon_font, fill=(255,255,255))
    
    # Name
    text_x = x + 30
    text_y = y + 60
    draw.text((text_x, text_y), name, font=font, fill=(255,255,255))
    
    # Status badge
    status = "ON" if enabled else "OFF"
    status_color = (0, 255, 0) if enabled else (255, 0, 0)
    badge_w = value_font.getlength(status) + 20
    draw.rounded_rectangle(
        [x + box_w - badge_w - 20, y + 60, x + box_w - 20, y + 95], 
        radius=8, 
        fill=(20, 20, 30, 230)
    )
    draw.text((x + box_w - badge_w - 10, y + 62), status, font=value_font, fill=status_color)

def fetch_image(url):
    """Download và convert image từ URL"""
    if not url: 
        return None
    try:
        if url.startswith('data:image'): 
            return Image.open(BytesIO(base64.b64decode(url.split(',', 1)[1]))).convert("RGB")
        response = requests.get(url, stream=True, timeout=3)
        response.raise_for_status()
        return Image.open(BytesIO(response.content)).convert("RGB")
    except: 
        return None

def format_time_compact(seconds):
    """Format uptime thành d h m s"""
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    parts = []
    if days > 0: parts.append(f"{int(days)}d")
    if hours > 0: parts.append(f"{int(hours)}h")
    if minutes > 0: parts.append(f"{int(minutes)}m")
    parts.append(f"{int(seconds)}s")
    return " ".join(parts)

def detect_platform():
    """
    Phát hiện platform đang chạy
    Returns: 'android', 'termux', 'windows', 'linux', 'macos'
    """
    system = platform.system().lower()
    
    # Check Termux (Android)
    if os.path.exists('/data/data/com.termux'):
        return 'termux'
    
    # Check Android (general)
    if system == 'linux':
        try:
            with open('/proc/version', 'r') as f:
                version = f.read().lower()
                if 'android' in version:
                    return 'android'
        except:
            pass
    
    # Check Windows
    if system == 'windows':
        return 'windows'
    
    # Check macOS
    if system == 'darwin':
        return 'macos'
    
    # Default Linux
    if system == 'linux':
        return 'linux'
    
    return system

def get_os_name():
    """
    Lấy tên OS hiển thị đẹp
    """
    plat = detect_platform()
    
    if plat == 'termux':
        return 'Termux (Android)'
    elif plat == 'android':
        return 'Android'
    elif plat == 'windows':
        # Windows version
        try:
            ver = platform.version()
            if '10' in ver:
                return 'Windows 10'
            elif '11' in ver:
                return 'Windows 11'
            else:
                return f'Windows {platform.release()}'
        except:
            return 'Windows'
    elif plat == 'macos':
        try:
            ver = platform.mac_ver()[0]
            return f'macOS {ver}'
        except:
            return 'macOS'
    elif plat == 'linux':
        try:
            # Try to get Linux distro
            import distro
            return f'{distro.name()} {distro.version()}'
        except:
            return 'Linux'
    
    return platform.system()

def get_disk_usage():
    """
    Lấy disk usage cho tất cả platform
    Returns: (used_gb, total_gb) hoặc None
    """
    plat = detect_platform()
    
    try:
        if plat in ['windows']:
            # Windows: dùng C:/ drive
            disk = psutil.disk_usage('C:/')
        elif plat in ['termux', 'android']:
            # Android/Termux: thử nhiều path
            paths_to_try = [
                '/data',
                '/storage/emulated/0',
                '/sdcard',
                os.path.expanduser('~'),
                '/'
            ]
            
            disk = None
            for path in paths_to_try:
                try:
                    if os.path.exists(path):
                        disk = psutil.disk_usage(path)
                        break
                except:
                    continue
            
            if not disk:
                disk = psutil.disk_usage('/')
        else:
            # Linux/macOS: dùng root
            disk = psutil.disk_usage('/')
        
        used_gb = disk.used / (1024**3)
        total_gb = disk.total / (1024**3)
        return (used_gb, total_gb)
        
    except Exception as e:
        print(f"[ERROR] Cannot get disk usage: {e}")
        return None

def get_system_metrics():
    """
    Lấy system metrics cho tất cả platform
    """
    ram = psutil.virtual_memory()
    uptime = format_time_compact(time.time() - start_time)
    
    # CPU frequency
    try:
        cpu_freq = psutil.cpu_freq()
        if cpu_freq and cpu_freq.current:
            cpu = f"{cpu_freq.current:.0f}Mhz"
        else:
            cpu = "N/A"
    except:
        cpu = "N/A"
    
    # OS name
    os_name = get_os_name()
    
    # Disk usage
    disk_info = get_disk_usage()
    if disk_info:
        disk_used, disk_total = disk_info
        disk_str = f"{disk_used:.0f}/{disk_total:.0f}GB"
    else:
        disk_str = "N/A"
    
    return [
        ("🧭", "Uptime", uptime),
        ("📜", "OS", os_name),
        ("📊", "RAM", f"{ram.used/(1024**2):.0f}/{ram.total/(1024**2):.0f}MB"),
        ("💾", "Disk", disk_str),
        ("⚡", "CPU", cpu)
    ]

def get_network_info():
    """Lay thong tin network: ten interface dang hoat dong + tong luu luong."""
    iface_name = "N/A"
    driver_name = "N/A"
    is_wifi = False
    try:
        stats = psutil.net_if_stats()
        addrs = psutil.net_if_addrs()
        candidates = [n for n, s in stats.items() if s.isup and n.lower() not in ("lo", "loopback")]
        if candidates:
            def score(n):
                nl = n.lower()
                if "wi" in nl or "wlan" in nl:
                    return 0
                if "eth" in nl or "en" in nl:
                    return 1
                return 2
            candidates.sort(key=score)
            iface_name = candidates[0]
            is_wifi = score(iface_name) == 0
            driver_name = iface_name
    except Exception:
        pass

    sent_gb = recv_gb = 0.0
    try:
        io = psutil.net_io_counters()
        sent_gb = io.bytes_sent / (1024 ** 3)
        recv_gb = io.bytes_recv / (1024 ** 3)
    except Exception:
        pass

    return {
        "interface": iface_name,
        "driver": driver_name,
        "protocol": "Wi-Fi" if is_wifi else "Ethernet",
        "connect_type": "Không dây" if is_wifi else "Có kết nối" if iface_name != "N/A" else "N/A",
        "sent_gb": sent_gb,
        "recv_gb": recv_gb,
    }


def draw_bot_dashboard(avatar_url, bot_name, dev_tag, is_online=True):
    """
    Ve dashboard 'detail' theo dung mau: header (avatar/ten/dev/online) +
    THONG SO BOT + HIEU NANG HE THONG (co progress bar) + NETWORK ACTIVITY.
    """
    from modules import _glasscard as gc

    W = 780
    accent = (150, 110, 255)  # tim/violet giong mau

    ram = psutil.virtual_memory()
    disk_info = get_disk_usage()
    disk_used_gb, disk_total_gb = disk_info if disk_info else (0, 0)
    cpu_percent = psutil.cpu_percent(interval=0.3)
    ram_percent = ram.percent
    disk_percent = (disk_used_gb / disk_total_gb * 100) if disk_total_gb else 0

    try:
        cpu_name = platform.processor() or "N/A"
    except Exception:
        cpu_name = "N/A"
    try:
        cpu_cores = psutil.cpu_count(logical=False) or 0
    except Exception:
        cpu_cores = 0
    try:
        proc_count = len(psutil.pids())
    except Exception:
        proc_count = 0
    try:
        thread_count = sum(p.num_threads() for p in psutil.process_iter(['num_threads'])
                            if p.info.get('num_threads')) if proc_count < 500 else 0
    except Exception:
        thread_count = 0

    os_name = get_os_name()
    os_uptime = format_time_compact(time.time() - psutil.boot_time())
    bot_uptime = format_time_compact(time.time() - start_time)
    bot_ram_str = f"{ram.used/(1024**2):.2f} MB / {ram.total/(1024**2):.2f} MB"
    version_str = f"{VERSION_STR} - Based with Python {platform.python_version()}"

    net = get_network_info()

    # ---- do truoc chieu cao ----
    header_h = 170
    gap = 20
    left_panel1_h = 200   # THONG SO BOT
    left_panel2_h = 200   # NETWORK ACTIVITY
    right_panel_h = left_panel1_h + gap + left_panel2_h  # HIEU NANG (bang tong 2 panel trai)
    H = header_h + gap + right_panel_h + 30

    canvas = gc.draw_blob_background(W, H, accent_override=accent)
    draw = ImageDraw.Draw(canvas)

    # ---------------- header ----------------
    av_img = gc.fetch_image(avatar_url, None)
    av_r = 42
    gc.avatar_with_ring(canvas, av_img, 30 + av_r, 30 + av_r, av_r, accent, ring_width=4)

    name_font = gc.get_font(gc.TITLE_FONT, 32)
    dev_font = gc.get_font(gc.TEXT_FONT_MED, 20)
    text_x = 30 + av_r * 2 + 24
    draw.text((text_x, 26), bot_name, font=name_font, fill=(255, 255, 255))
    draw.text((text_x, 66), dev_tag, font=dev_font, fill=(190, 195, 220))

    badge_font = gc.get_font(gc.TEXT_FONT_MED, 18)
    badge_text = "Online" if is_online else "Offline"
    badge_color = (60, 200, 130) if is_online else (200, 70, 70)
    bw = draw.textbbox((0, 0), badge_text, font=badge_font)[2]
    bx1, by1 = W - 30 - bw - 28, 34
    bx2, by2 = W - 30, 34 + 32
    draw.rounded_rectangle((bx1, by1, bx2, by2), radius=16, fill=(40, 46, 42), outline=badge_color, width=2)
    draw.ellipse((bx1 + 12, by1 + 12, bx1 + 20, by1 + 20), fill=badge_color)
    draw.text((bx1 + 26, by1 + 6), badge_text, font=badge_font, fill=(255, 255, 255))

    label_font = gc.get_font(gc.TEXT_FONT_MED, 18)
    val_font = gc.get_font(gc.TITLE_FONT, 21)

    def panel_header(x, y, w, title):
        draw.text((x + 24, y + 18), title, font=gc.get_font(gc.TITLE_FONT, 20), fill=(*accent, 255))

    def kv_row(x, y, label, value, max_w):
        draw.text((x, y), label, font=label_font, fill=(175, 180, 205))
        v = gc.fit_text(draw, str(value), val_font, max_w)
        draw.text((x, y + 24), v, font=val_font, fill=(255, 255, 255))

    def progress_bar(x, y, w, h, pct, color, label, value_text):
        draw.text((x, y), label, font=label_font, fill=(175, 180, 205))
        vw = draw.textbbox((0, 0), value_text, font=label_font)[2]
        draw.text((x + w - vw, y), value_text, font=label_font, fill=(220, 222, 235))
        bar_y = y + 26
        draw.rounded_rectangle((x, bar_y, x + w, bar_y + h), radius=h // 2, fill=(60, 58, 82))
        fill_w = max(h, int(w * max(0, min(100, pct)) / 100))
        draw.rounded_rectangle((x, bar_y, x + fill_w, bar_y + h), radius=h // 2, fill=color)

    # ---------------- cot trai ----------------
    left_x, left_w = 30, 330
    top_y = header_h

    gc.glass_panel(canvas, (left_x, top_y, left_x + left_w, top_y + left_panel1_h), radius=22, alpha=22, blur=16)
    panel_header(left_x, top_y, left_w, "THÔNG SỐ BOT")
    ly = top_y + 56
    kv_row(left_x + 24, ly, "Tên định danh", bot_name, left_w - 48); ly += 56
    kv_row(left_x + 24, ly, "Thời gian hoạt động", bot_uptime, left_w - 48); ly += 56
    kv_row(left_x + 24, ly, "Bộ nhớ sử dụng", bot_ram_str, left_w - 48)

    top_y2 = top_y + left_panel1_h + gap
    gc.glass_panel(canvas, (left_x, top_y2, left_x + left_w, top_y2 + left_panel2_h), radius=22, alpha=22, blur=16)
    panel_header(left_x, top_y2, left_w, "NETWORK ACTIVITY")
    ly = top_y2 + 56
    kv_row(left_x + 24, ly, "Interface Name", net["interface"], left_w - 48); ly += 48
    kv_row(left_x + 24, ly, "Protocol Type", net["protocol"], left_w - 48); ly += 48
    draw.text((left_x + 24, ly), "Total Traffic", font=label_font, fill=(175, 180, 205))
    traffic_font = gc.get_font(gc.TITLE_FONT, 18)
    draw.text((left_x + 24, ly + 24), f"{net['sent_gb']:.2f} GB Sent", font=traffic_font, fill=(255, 255, 255))
    draw.text((left_x + 24, ly + 46), f"{net['recv_gb']:.2f} GB Received", font=traffic_font, fill=(255, 255, 255))

    # ---------------- cot phai ----------------
    right_x = left_x + left_w + gap
    right_w = W - right_x - 30
    gc.glass_panel(canvas, (right_x, top_y, right_x + right_w, top_y + right_panel_h), radius=22, alpha=22, blur=16)
    panel_header(right_x, top_y, right_w, "HIỆU NĂNG HỆ THỐNG")
    ry = top_y + 56
    kv_row(right_x + 24, ry, "Operating System", os_name, right_w - 48); ry += 56
    kv_row(right_x + 24, ry, "Uptime OS", os_uptime, right_w - 48); ry += 56
    kv_row(right_x + 24, ry, "CPU Model", cpu_name, right_w - 48); ry += 56
    kv_row(right_x + 24, ry, "Processes", f"{proc_count} Tiến trình | {thread_count} Luồng", right_w - 48); ry += 66

    bar_w = right_w - 48
    progress_bar(right_x + 24, ry, bar_w, 14, cpu_percent, (255, 100, 110),
                 "CPU Usage", f"{cpu_cores} Nhân · {cpu_percent:.1f}%")
    ry += 56
    progress_bar(right_x + 24, ry, bar_w, 14, ram_percent, (90, 170, 255),
                 "RAM Usage", f"{ram.used/(1024**3):.1f} / {ram.total/(1024**3):.1f} GB")
    ry += 56
    progress_bar(right_x + 24, ry, bar_w, 14, disk_percent, (80, 210, 160),
                 "Disk Usage", f"{disk_used_gb:.1f} / {disk_total_gb:.1f} GB")

    return canvas.convert("RGB")


VERSION_STR = "3.0.0"


def autosave(img, quality=97):
    """Lưu image vào temp file"""
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
        img.convert("RGB").save(
            tf, "JPEG", 
            quality=quality, 
            dpi=(180,180), 
            optimize=True, 
            progressive=True, 
            subsampling=0
        )
        return tf.name

def admin():
    """Lấy admin ID từ seting.json"""
    try:
        if os.path.exists('seting.json'):
            with open('seting.json','r') as f: 
                return json.load(f).get('account_bot')
    except: 
        return None

def handle_detail_command(message, message_object, thread_id, thread_type, author_id, client):
    """Main handler cho lệnh detail"""
    output_path = None
    try:
        # Get user info
        user_id_to_fetch = admin() or author_id
        user_info = client.fetchUserInfo(user_id_to_fetch)
        user_data = user_info.changed_profiles.get(str(user_id_to_fetch), {}) if user_info and hasattr(user_info, 'changed_profiles') else {}
        avatar_url = user_data.get("avatar")
        author_name = user_data.get("displayName", "Unknown")

        # Doc ten bot / phien ban tu seting.json (co san trong SeaBot)
        bot_name = "Bot"
        version_display = "1.0.0"
        try:
            with open("seting.json", "r", encoding="utf-8") as f:
                cfg = json.load(f)
                bot_name = cfg.get("name_bot") or bot_name
                version_display = cfg.get("version") or version_display
        except Exception:
            pass
        global VERSION_STR
        VERSION_STR = version_display
        dev_tag = f"Developer ⇾ {author_name} ⇾"

        # Generate image (dashboard giong mau: bot info + he thong + network)
        image_to_save = draw_bot_dashboard(avatar_url, bot_name, dev_tag, is_online=True)
        
        # Save and send
        output_path = autosave(image_to_save)
        if os.path.exists(output_path):
            with Image.open(output_path) as im: 
                width, height = im.size
            client.sendLocalImage(
                output_path, 
                thread_id=thread_id, 
                thread_type=thread_type, 
                width=width, 
                height=height, 
                ttl=120000
            )
    except Exception as e:
        client.sendMessage(
            Message(text=f"• An error occurred: {str(e)}"), 
            thread_id, 
            thread_type, 
            ttl=60000
        )
    finally:
        if output_path and os.path.exists(output_path): 
            os.remove(output_path)

def PTA():
    return {'detail': handle_detail_command}
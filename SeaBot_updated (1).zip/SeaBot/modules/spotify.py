"""
spotify.py — tim bai hat tren Spotify (metadata that + bia dep), phat am thanh
thuc te qua SoundCloud (Spotify khong cho tai nhac truc tiep tru tai khoan Premium).
Dung lai dung pipeline convert/upload da chay tot cua modules/scl.py.
Khong Mongo.
"""
import os
import re
import time
import requests
from concurrent.futures import ThreadPoolExecutor
from zlapi.models import Message, ThreadType

from modules import _glasscard as gc
from modules.scl import (
    get_styled_msg, get_user_name, get_user_avatar, force_delete_msg, delete_file,
    search_songs as scl_search_songs, get_music_stream_url, process_audio, ms_to_mmss
)

des = {
    'version': "1.0.0",
    'credits': "Seatzk",
    'description': "Tìm nhạc trên Spotify (âm thanh phát qua SoundCloud)",
    'power': "Thành viên"
}

SEARCH_TIMEOUT = 120
_user_states = {}

_access_token = None
_token_expire_at = 0


def _get_guest_token():
    global _access_token, _token_expire_at
    try:
        headers = {"User-Agent": "Mozilla/5.0", "Accept": "application/json", "Referer": "https://open.spotify.com/"}
        r = requests.get(
            "https://open.spotify.com/get_access_token?reason=transport&productType=web_player",
            headers=headers, timeout=10
        )
        if r.status_code == 200:
            j = r.json() or {}
            token = j.get("accessToken")
            exp_ms = j.get("accessTokenExpirationTimestampMs")
            if token:
                _access_token = token
                _token_expire_at = int(exp_ms // 1000) if exp_ms else int(time.time() + 3600)
                return token
    except Exception:
        pass
    return None


def _token():
    global _access_token, _token_expire_at
    now = int(time.time())
    if _access_token and now < _token_expire_at - 15:
        return _access_token
    t = _get_guest_token()
    if not t:
        raise RuntimeError("Không lấy được token Spotify (thử lại sau).")
    return t


def search_songs_spotify(query, limit=10):
    headers = {"Authorization": f"Bearer {_token()}", "User-Agent": "Mozilla/5.0"}
    r = requests.get(
        "https://api.spotify.com/v1/search",
        params={"q": query, "type": "track", "limit": limit},
        headers=headers, timeout=10
    )
    if r.status_code == 401:
        global _access_token
        _access_token = None
        headers = {"Authorization": f"Bearer {_token()}", "User-Agent": "Mozilla/5.0"}
        r = requests.get("https://api.spotify.com/v1/search",
                          params={"q": query, "type": "track", "limit": limit}, headers=headers, timeout=10)
    r.raise_for_status()
    items = ((r.json() or {}).get("tracks") or {}).get("items") or []

    out = []
    for x in items:
        artists = ", ".join(a.get("name", "") for a in (x.get("artists") or []))
        images = (x.get("album") or {}).get("images") or []
        cover = images[0]["url"] if images else ""
        duration = ms_to_mmss(x.get("duration_ms", 0))
        out.append((
            x.get("id"), x.get("name") or "Không rõ", cover, duration,
            int(x.get("popularity") or 0), 0, 0, artists
        ))
    return out


def handle_spotify_command(message_text, message_object, thread_id, thread_type, author_id, client):
    name = get_user_name(client, author_id)
    parts = message_text.strip().split()
    query_or_choice = " ".join(parts[1:]) if len(parts) > 1 else ""
    if not query_or_choice and author_id in _user_states:
        m = re.search(r"\b(\d+)\b", message_text.strip())
        if m:
            query_or_choice = m.group(1)

    compressed_path_to_delete = None
    try:
        if query_or_choice.isdigit() and author_id in _user_states:
            state = _user_states[author_id]
            if time.time() - state['time_of_search'] > SEARCH_TIMEOUT:
                del _user_states[author_id]
                return

            songs = state['songs']
            index = int(query_or_choice) - 1
            if not (0 <= index < len(songs)):
                client.replyMessage(get_styled_msg(f"@{name} lựa chọn không hợp lệ.", author_id, name),
                                     message_object, thread_id, thread_type, ttl=60000)
                return

            _id, title, cover, duration_str, popularity, _l, _c, artist = songs[index]
            send_response_obj = state.get('send_response')
            del _user_states[author_id]
            force_delete_msg(client, send_response_obj, thread_id)

            wait_msg = client.replyMessage(
                get_styled_msg(f"@{name} Đang tìm nguồn phát cho '{title}'...", author_id, name),
                message_object, thread_id, thread_type, ttl=120000)

            # Spotify khong cho phat nhac truc tiep -> tim ban ghi tuong ung tren SoundCloud
            sc_candidates = scl_search_songs(f"{title} {artist}")
            if not sc_candidates:
                raise Exception("Không tìm được nguồn phát tương ứng trên SoundCloud.")
            sc_link = sc_candidates[0][0]

            requester_avatar = get_user_avatar(client, author_id)

            with ThreadPoolExecutor(max_workers=2) as executor:
                audio_stream_url = get_music_stream_url(sc_link)
                if not audio_stream_url:
                    raise Exception("Không lấy được stream URL.")
                audio_future = executor.submit(process_audio, audio_stream_url, title)
                image_future = executor.submit(
                    gc.draw_music_detail_card, title, artist, duration_str, popularity, 0, 0,
                    cover, requester_avatar, "Spotify", (30, 215, 96),
                    "Phát qua SoundCloud (Spotify không cho tải nhạc trực tiếp)"
                )
                public_url, compressed_path_to_delete = audio_future.result()
                detail_image_path = image_future.result()

            content = f"@{name}\n> From Spotify <\nNhạc Bạn Chọn Đây!!"
            client.send(get_styled_msg(content, author_id, name), thread_id=thread_id, thread_type=thread_type, ttl=210000)
            force_delete_msg(client, wait_msg, thread_id)

            from PIL import Image
            with Image.open(detail_image_path) as im:
                w, h = im.size
            client.sendLocalImage(detail_image_path, thread_id=thread_id, thread_type=thread_type,
                                   width=w, height=h, message=None, ttl=210000)
            delete_file(detail_image_path)

            client.sendRemoteVoice(public_url, thread_id=thread_id, thread_type=thread_type,
                                    fileSize=int(os.path.getsize(compressed_path_to_delete)), ttl=1800000)
            return

        if not query_or_choice:
            client.replyMessage(get_styled_msg(f"@{name} Vui lòng nhập tên bài hát.", author_id, name),
                                 message_object, thread_id, thread_type, ttl=60000)
            return

        songs = search_songs_spotify(query_or_choice)
        if not songs:
            client.replyMessage(get_styled_msg(f"@{name} Không tìm thấy kết quả cho '{query_or_choice}'.", author_id, name),
                                 message_object, thread_id, thread_type, ttl=60000)
            return

        img_path = gc.draw_music_list_card(songs, "Spotify", (30, 215, 96))
        from PIL import Image
        with Image.open(img_path) as im:
            w, h = im.size

        send_response = client.sendLocalImage(
            img_path, thread_id=thread_id, thread_type=thread_type, width=w, height=h,
            message=get_styled_msg(f"@{name} hãy trả lời tin nhắn này bằng số index để phát", author_id, name),
            ttl=120000
        )
        _user_states[author_id] = {'songs': songs, 'time_of_search': time.time(), 'send_response': send_response}
        delete_file(img_path)

    except Exception as e:
        client.replyMessage(get_styled_msg(f"@{name} đã xảy ra lỗi: {e}", author_id, name),
                             message_object, thread_id, thread_type, ttl=60000)
    finally:
        if compressed_path_to_delete:
            delete_file(compressed_path_to_delete)


def PTA():
    return {'spotify': handle_spotify_command}

"""
topchat.py — bang xep hang thanh vien nhan tin nhieu nhat trong nhom.
Luu dem tin nhan bang file JSON local (data/topchat.json) - khong Mongo.

Can 1 dong hook trong main.py (onMessage) goi topchat.count_message(...)
moi khi co tin nhan moi, xem huong dan trong README hoac phan duoi file nay.
"""
import os
import json
import threading
from zlapi.models import Message, ThreadType

from modules import _glasscard as gc

des = {
    'version': "1.0.0",
    'credits': "Seatzk",
    'description': "Bảng xếp hạng nhắn tin nhiều nhất trong nhóm (top chat)",
    'power': "Thành viên"
}

DATA_FILE = "data/topchat.json"
_lock = threading.Lock()


def _load():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(data):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, DATA_FILE)


def count_message(client, message_object, thread_id, thread_type, author_id):
    """Goi ham nay trong main.py::onMessage cho MOI tin nhan de dem."""
    try:
        if thread_type != ThreadType.GROUP:
            return
        with _lock:
            data = _load()
            g = data.setdefault(str(thread_id), {})
            g[str(author_id)] = int(g.get(str(author_id), 0)) + 1
            _save(data)
    except Exception:
        pass


def _get_name_avatar(client, uid):
    try:
        info = client.fetchUserInfo(uid)
        d = info.changed_profiles.get(str(uid), {}) if info and info.changed_profiles else {}
        return d.get("zaloName") or d.get("displayName") or "Ẩn danh", d.get("avatar") or ""
    except Exception:
        return "Ẩn danh", ""


def draw_topchat_card(group_name, ranking):
    """ranking: list[(uid, name, avatar_url, count)] da sap xep giam dan."""
    W = 900
    row_h = 100
    header_h = 110
    H = header_h + len(ranking) * row_h + 40

    accent = (255, 190, 60)
    canvas = gc.draw_blob_background(W, H, accent_override=accent)
    draw = __import__("PIL.ImageDraw", fromlist=["ImageDraw"]).Draw(canvas)

    title_font = gc.get_font(gc.TITLE_FONT, 38)
    sub_font = gc.get_font(gc.TEXT_FONT_MED, 22)
    draw.text((40, 26), f"🏆 Top Chat · {group_name}", font=title_font, fill=(255, 255, 255))
    draw.text((40, 74), "Thành viên nhắn tin nhiều nhất nhóm", font=sub_font, fill=(210, 214, 230))

    medal = {0: "#1", 1: "#2", 2: "#3"}
    name_font = gc.get_font(gc.TEXT_FONT, 26)
    count_font = gc.get_font(gc.TITLE_FONT, 26)
    rank_font = gc.get_font(gc.TITLE_FONT, 28)

    y = header_h
    for i, (uid, name, avatar, count) in enumerate(ranking):
        box = (30, y + 8, W - 30, y + row_h - 8)
        gc.glass_panel(canvas, box, radius=20, alpha=20, blur=14)

        rank_label = medal.get(i, str(i + 1))
        draw.text((55, y + row_h // 2 - 18), rank_label, font=rank_font, fill=(*accent, 255))

        av = gc.fetch_image(avatar, None)
        cx, cy, r = 140, y + row_h // 2, 32
        gc.avatar_with_ring(canvas, av, cx, cy, r, accent, ring_width=3)

        text_x = 190
        max_w = W - text_x - 140
        n = gc.fit_text(draw, name, name_font, max_w)
        draw.text((text_x, y + row_h // 2 - 16), n, font=name_font, fill=(255, 255, 255))

        count_text = f"{count} tin"
        cw = draw.textbbox((0, 0), count_text, font=count_font)[2]
        draw.text((W - 60 - cw, y + row_h // 2 - 16), count_text, font=count_font, fill=(*accent, 255))

        y += row_h

    return canvas.convert("RGB")


def handle_topchat_command(message, message_object, thread_id, thread_type, author_id, client):
    if thread_type != ThreadType.GROUP:
        client.send(Message(text="Lệnh này chỉ dùng được trong nhóm."), thread_id=thread_id, thread_type=thread_type)
        return

    data = _load()
    group_counts = data.get(str(thread_id), {})
    if not group_counts:
        client.send(Message(text="Chưa có dữ liệu top chat cho nhóm này (cần thêm thời gian để bot đếm tin nhắn)."),
                     thread_id=thread_id, thread_type=thread_type)
        return

    top_items = sorted(group_counts.items(), key=lambda kv: kv[1], reverse=True)[:10]

    ranking = []
    for uid, count in top_items:
        name, avatar = _get_name_avatar(client, uid)
        ranking.append((uid, name, avatar, count))

    group_name = "Nhóm"
    try:
        gi = client.fetchGroupInfo(thread_id)
        group_name = gi.gridInfoMap.get(thread_id, {}).get("name", "Nhóm")
    except Exception:
        pass

    img = draw_topchat_card(group_name, ranking)
    import time
    op = f"modules/cache/topchat_{int(time.time()*1000)}.png"
    os.makedirs("modules/cache", exist_ok=True)
    img.save(op, format="PNG")
    try:
        client.sendLocalImage(op, thread_id=thread_id, thread_type=thread_type,
                               width=img.width, height=img.height, message=None, ttl=180000)
    finally:
        if os.path.exists(op):
            os.remove(op)


def PTA():
    return {'topchat': handle_topchat_command}

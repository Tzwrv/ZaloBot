from zlapi.models import Message, MultiMsgStyle, MessageStyle

des = {
    'version': '1.0.0',
    'credits': "Seatzk",
    'description': 'Gõ "prefix" (không cần ký tự lệnh) để xem prefix hiện tại của bot.',
}


def handle_show_prefix(message, message_object, thread_id, thread_type, author_id, client):
    try:
        current_prefix = client.command_handler.current_prefix or "no prefix"
    except Exception:
        current_prefix = "?"

    text = f"🔧 Prefix hiện tại của bot là: '{current_prefix}'"

    styles = MultiMsgStyle([
        MessageStyle(offset=0, length=len(text), style="font", size="14", auto_format=False),
        MessageStyle(offset=0, length=len(text), style="bold", auto_format=False),
    ])

    client.replyMessage(Message(text=text, style=styles), message_object, thread_id, thread_type, ttl=30000)


def PTA():
    return {
        'prefix': handle_show_prefix
    }

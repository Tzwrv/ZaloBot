import os
import gc
import json
import shutil
import time
import psutil
from zlapi.models import Message, MultiMsgStyle, MessageStyle

from config import ADMIN, PREFIX, HEADER_STYLE

des = {
    'version': "1.0.0",
    'credits': "Seatzk",
    'description': "Làm mới bot (dọn cache RAM, xoá file tạm, gom rác) khi thấy bot yếu/lag",
    'power': "Admin"
}

# Các dict cache trong instance Client được coi là an toàn để xoá (không phải config,
# không phải danh sách cấm/whitelist) — chỉ là dữ liệu tạm tích luỹ trong lúc chạy.
SAFE_CACHE_ATTRS = [
    "group_info_cache",
    "temp_thread_storage",
    "search_results",
    "search_result_messages",
    "last_sms_times",
    "scl_user_states",
    "yt_user_states",
]

# Các thư mục chứa ảnh/audio tạm sinh ra khi xử lý lệnh (menu, admin list, weather, ...)
TEMP_DIRS = [
    "temp_images",
    "modules/cache/menu_temp",
    "modules/cache/listcmd_temp",
    "modules/cache/admin_menu_temp",
]


def is_admin(author_id):
    author_id = str(author_id)
    try:
        with open('seting.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        admin_id = str(settings.get('admin', ''))
        adm_list = [str(uid) for uid in settings.get('adm', [])]
        if author_id == admin_id or author_id in adm_list:
            return True
    except Exception:
        pass
    return author_id in ADMIN


def _get_mem_mb():
    try:
        return round(psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024), 1)
    except Exception:
        return None


def _clear_temp_files():
    removed = 0
    for d in TEMP_DIRS:
        if not os.path.isdir(d):
            continue
        for name in os.listdir(d):
            path = os.path.join(d, name)
            try:
                if os.path.isfile(path):
                    os.remove(path)
                    removed += 1
                elif os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                    removed += 1
            except Exception:
                pass
    return removed


def _clear_client_caches(client):
    cleared = []
    for attr in SAFE_CACHE_ATTRS:
        if hasattr(client, attr):
            try:
                val = getattr(client, attr)
                if isinstance(val, dict):
                    n = len(val)
                    val.clear()
                    cleared.append(f"{attr} ({n})")
                elif isinstance(val, list):
                    n = len(val)
                    val.clear()
                    cleared.append(f"{attr} ({n})")
            except Exception:
                pass
    # tận dụng luôn hàm dọn kết quả tìm kiếm hết hạn sẵn có, nếu có
    if hasattr(client, "cleanup_expired_search_results"):
        try:
            client.cleanup_expired_search_results()
        except Exception:
            pass
    return cleared


def handle_fixlag_command(message, message_object, thread_id, thread_type, author_id, client):
    author_id = str(author_id)
    if not is_admin(author_id):
        client.replyMessage(
            Message(text="🚫 Chỉ Admin mới được dùng lệnh làm mới bot này!"),
            message_object, thread_id, thread_type, ttl=60000
        )
        return

    client.replyMessage(
        Message(text="🛠️ Đang làm mới bot, chờ chút xíu..."),
        message_object, thread_id, thread_type, ttl=60000
    )

    mem_before = _get_mem_mb()
    t0 = time.time()

    cleared_caches = _clear_client_caches(client)
    removed_files = _clear_temp_files()
    collected = gc.collect()

    mem_after = _get_mem_mb()
    elapsed = round(time.time() - t0, 2)

    lines = [
        "✅ ĐÃ LÀM MỚI BOT XONG ✅",
        f"➜ Bộ nhớ trước: {mem_before} MB" if mem_before is not None else "➜ Bộ nhớ trước: không đọc được",
        f"➜ Bộ nhớ sau: {mem_after} MB" if mem_after is not None else "➜ Bộ nhớ sau: không đọc được",
        f"➜ Cache RAM đã dọn: {', '.join(cleared_caches) if cleared_caches else 'không có gì để dọn'}",
        f"➜ File tạm đã xoá: {removed_files}",
        f"➜ Đối tượng rác thu gom (gc): {collected}",
        f"➜ Thời gian xử lý: {elapsed}s",
        "🚀 Bot đã khoẻ lại, dùng tiếp thoải mái nhé!",
    ]
    text = "\n".join(lines)
    styles = MultiMsgStyle([
        MessageStyle(offset=0, length=len(lines[0]), style="bold", auto_format=False),
        MessageStyle(offset=0, length=len(lines[0]), style="color", color="#22c55e", auto_format=False),
    ])
    client.replyMessage(Message(text=text, style=styles), message_object, thread_id, thread_type, ttl=90000)


def PTA():
    return {
        'fixlag': handle_fixlag_command,
    }

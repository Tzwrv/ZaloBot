import os
import re
import random
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageChops
import requests
from datetime import datetime
import concurrent.futures
import json
from zlapi.models import *

C1, C2, C3, RESET = "\033[38;2;0;255;204m", "\033[38;2;0;255;149m", "\033[38;2;255;51;102m", "\033[0m"

des = {
    'version': "1.4.0", 
    'credits': "Seatzk", 
    'description': "Event image Emoji support", 
    'power': "Thành viên"
}

CACHE = "modules/cache"
FONT_PATH = "modules/cache/font/BeVietnamPro-Bold.ttf"
EMOJI_FONT_PATH = "modules/cache/font/NotoEmoji-Bold.ttf"
CJK_FONT_PATH = "modules/cache/font/Noto Sans CJK Regular.otf"
EVENT_SETTINGS_FILE = "data/welcome_setting.json"
LINK_BACKGROUND_DEFAULT = "https://photo-stal-7.zdn.vn/gr/jpg/44d0be0596b458ea01a5/1538102626601520187.jpg"
LINK_BACKGROUND_DEFAULT_ZALO = "https://cover-talk.zadn.vn/default"

def get_font_for_char(char, font, emoji_font, cjk_font):
    """Hàm tự động nhận diện ký tự để chọn đúng Font (Emoji, CJK, hoặc mặc định)"""
    try:
        import emoji as emoji_mod
        if emoji_mod.emoji_count(char):
            return emoji_font
    except ImportError:
        if re.match(r'[\U00010000-\U0010ffff]|[\u2600-\u27BF]', char):
            return emoji_font
    
    o = ord(char)
    if (0x4E00 <= o <= 0x9FFF) or \
       (0x3400 <= o <= 0x4DBF) or \
       (0x20000 <= o <= 0x2A6DF) or \
       (0x3040 <= o <= 0x309F) or \
       (0x30A0 <= o <= 0x30FF) or \
       (0xFF00 <= o <= 0xFFEF) or \
       o == 0x76ca:
        return cjk_font
    return font

def get_font(path, size, is_emoji=False):
    """Hàm load font hỗ trợ Emoji"""
    try:
        if os.path.exists(path):
            if is_emoji:
                try:
                    return ImageFont.truetype(path, size, embedded_color=True)
                except Exception:
                    pass
            return ImageFont.truetype(path, size)
    except Exception:
        pass
    return ImageFont.load_default()

def load_allowed_groups():
    if os.path.exists(EVENT_SETTINGS_FILE):
        try:
            with open(EVENT_SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f).get("groups", [])
        except:
            pass
    return []

def hex_to_rgba(hex_color, alpha=255):
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 6:
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        return (r, g, b, alpha)
    return (255, 255, 255, alpha)

def create_gradient_image(width, height, stops, horizontal=True):
    img = Image.new("RGBA", (width, height))
    draw = ImageDraw.Draw(img)
    
    def get_color(ratio):
        if ratio <= stops[0][0]: return stops[0][1]
        if ratio >= stops[-1][0]: return stops[-1][1]
        for i in range(len(stops) - 1):
            r1, c1 = stops[i]
            r2, c2 = stops[i+1]
            if r1 <= ratio <= r2:
                range_ratio = (ratio - r1) / (r2 - r1)
                r = int(c1[0] + (c2[0] - c1[0]) * range_ratio)
                g = int(c1[1] + (c2[1] - c1[1]) * range_ratio)
                b = int(c1[2] + (c2[2] - c1[2]) * range_ratio)
                a = int(c1[3] + (c2[3] - c1[3]) * range_ratio)
                return (r, g, b, a)
        return stops[-1][1]

    if horizontal:
        for x in range(width):
            color = get_color(x / width)
            draw.line([(x, 0), (x, height)], fill=color)
    else:
        for y in range(height):
            color = get_color(y / height)
            draw.line([(0, y), (width, y)], fill=color)
    return img

def draw_mixed_text(draw, text, x, y, font_text, font_emoji, font_cjk, fill):
    """Hàm tự động vẽ Text xen kẽ Emoji và CJK căn giữa (render từng ký tự)"""
    total_width = 0
    for char in text:
        font_to_use = get_font_for_char(char, font_text, font_emoji, font_cjk)
        bbox = draw.textbbox((0, 0), char, font=font_to_use)
        total_width += (bbox[2] - bbox[0])
        
    current_x = x - (total_width / 2)
    
    for char in text:
        font_to_use = get_font_for_char(char, font_text, font_emoji, font_cjk)
        is_emoji = (font_to_use == font_emoji)
        draw.text((current_x, y), char, font=font_to_use, fill=fill, anchor="lm", embedded_color=is_emoji)
        bbox = draw.textbbox((0, 0), char, font=font_to_use)
        current_x += (bbox[2] - bbox[0])

def draw_text_with_gradient(canvas, text, font, x, y, colors):
    if not colors: 
        colors = ["#FFFFFF"]
        
    try:
        font_size = font.size
    except:
        font_size = 36
        
    font_emoji = get_font(EMOJI_FONT_PATH, font_size, is_emoji=True)
    font_cjk = get_font(CJK_FONT_PATH, font_size)
        
    if len(colors) == 1:
        draw = ImageDraw.Draw(canvas)
        draw_mixed_text(draw, text, x, y, font, font_emoji, font_cjk, hex_to_rgba(colors[0]))
        return

    grad_width = 800
    grad_height = 100
    colors_rgba = [hex_to_rgba(c) for c in colors]
    stops = [(i / max(1, len(colors_rgba) - 1), c) for i, c in enumerate(colors_rgba)]
    
    grad_img = create_gradient_image(grad_width, grad_height, stops, horizontal=True)
    
    temp_canvas = Image.new("RGBA", (grad_width, grad_height), (0, 0, 0, 0))
    temp_draw = ImageDraw.Draw(temp_canvas)
    
    draw_mixed_text(temp_draw, text, grad_width // 2, grad_height // 2, font, font_emoji, font_cjk, (255, 255, 255, 255))
    
    mask = temp_canvas.split()[3]
    paste_x = int(x - grad_width // 2)
    paste_y = int(y - grad_height // 2)
    
    canvas.paste(grad_img, (paste_x, paste_y), mask)

def get_link_background_default(cover_url):
    headers = {"User-Agent": "Mozilla/5.0"}
    if cover_url and cover_url != LINK_BACKGROUND_DEFAULT_ZALO:
        try:
            r = requests.get(cover_url, headers=headers, timeout=5)
            if r.status_code == 200:
                return Image.open(BytesIO(r.content)).convert("RGBA")
        except Exception as e:
            print(f"Lỗi tải cover: {e}")
    
    try:
        r = requests.get(LINK_BACKGROUND_DEFAULT, headers=headers, timeout=5)
        if r.status_code == 200:
            return Image.open(BytesIO(r.content)).convert("RGBA")
    except Exception as e:
        print(f"Lỗi tải background mặc định: {e}")
        
    return Image.new("RGBA", (1000, 300), (30, 30, 53, 255))

def create_event_image(userInfo, message_info, file_type):
    """
    Ve card su kien (welcome/goodbye/kicked/admin...) theo phong cach
    'glassmorphism + gradient blob' (dung chung voi info/scl/nct/spotify).
    Giu nguyen chu ky ham cu (userInfo, message_info, file_type) de khong
    phai sua process_group_event_image / handleGroupEvent.
    """
    from modules import _glasscard as gc

    accent_map = {
        "welcome": (90, 220, 150), "add_admin": (90, 220, 150),
        "goodbye": (150, 170, 210), "remove_admin": (150, 170, 210),
        "kicked": (255, 90, 100), "blocked": (255, 90, 100),
        "blocked_spam": (255, 90, 100), "blocked_spam_link": (255, 90, 100),
    }
    accent = accent_map.get(file_type, (160, 130, 255))

    W, H = 1200, 380
    canvas = gc.draw_blob_background(W, H, accent_override=accent)

    av_size = 260
    av_x = 70
    av_cy = H // 2
    av_img = gc.fetch_image(userInfo.get("avatar"), None)
    gc.avatar_with_ring(canvas, av_img, av_x + av_size // 2, av_cy, av_size // 2, accent, ring_width=7)

    draw = ImageDraw.Draw(canvas)
    text_x = av_x + av_size + 55
    max_w = W - text_x - 60

    title_font = gc.get_font(gc.TITLE_FONT, 58)
    name_font = gc.get_font(gc.TITLE_FONT, 40)
    sub_font = gc.get_font(gc.TEXT_FONT_MED, 30)
    author_font = gc.get_font(gc.TEXT_FONT_MED, 24)

    title = gc.fit_text(draw, message_info.get('title', ''), title_font, max_w)
    name = gc.fit_text(draw, message_info.get('userName', ''), name_font, max_w)
    sub = gc.fit_text(draw, message_info.get('subtitle', ''), sub_font, max_w)
    author = gc.fit_text(draw, message_info.get('author', ''), author_font, max_w)

    y = av_cy - 105
    draw.text((text_x, y), title, font=title_font, fill=(255, 255, 255))
    y += 68
    draw.text((text_x, y), name, font=name_font, fill=(*accent, 255))
    y += 54
    draw.text((text_x, y), sub, font=sub_font, fill=(225, 228, 240))
    y += 42
    draw.text((text_x, y), author, font=author_font, fill=(180, 185, 205))

    return canvas.convert("RGB")

def process_group_event_image(self, member_id, message_info, groupId, event_time, filename, file_type):
    op = None
    try:
        u = self.fetchUserInfo(member_id) or {}
        ud = {}
        if isinstance(u, dict):
            ud = u.get(member_id, u.get('changed_profiles', {}).get(member_id, {}))
            if not ud and ('avatar' in u or 'avt' in u):
                ud = u
                
        userInfo = {
            'avatar': ud.get('avatar') or ud.get('avt') or "",
            'cover': ud.get('cover') or "",
            'name': ud.get('zaloName') or ud.get('displayName') or ud.get('dpn') or message_info.get('fallbackName', 'không xác định')
        }
        
        image = create_event_image(userInfo, message_info, file_type)
        
        if not os.path.exists(CACHE):
            os.makedirs(CACHE)
            
        op = os.path.join(CACHE, filename)
        image.save(op, format="PNG", quality=100)
        
        # Cái này đang chỉ gửi ảnh trơn, không có thông báo văn bản tag tiếc rườm rà
        self.sendLocalImage(
            op, 
            thread_id=groupId, 
            thread_type=ThreadType.GROUP, 
            width=image.width, 
            height=image.height,
            ttl=320000
        )
    except Exception as e:
        print(f"Error processing group event image: {e}")
    finally:
        if op and os.path.exists(op):
            os.remove(op)

        try:
            event_names = {
                "welcome": "THÀNH VIÊN MỚI", "goodbye": "RỜI NHÓM", "kicked": "SÚT TV",
                "add_admin": "THÊM ADMIN (KEY BẠC)", "remove_admin": "GỠ ADMIN (KEY BẠC)"
            }
            display_name = event_names.get(file_type, file_type.upper())
            g_info = getattr(self, 'group_info_cache', {}).get(groupId) or self.fetchGroupInfo(groupId).gridInfoMap.get(groupId, {})
            print(f"{C1}┌── {C2}[ {display_name} ]{C1} ──────────────────────┐")
            print(f"{C1}│ {C2}Nhóm: {RESET}{g_info.get('name', 'Nhóm ẩn')}")
            print(f"{C1}│ {C2}User: {RESET}{userInfo.get('name', 'Thành viên')}")
            print(f"{C1}└────────────────────────────────────────────┘{RESET}")
        except: pass

def handleGroupEvent(self, eventData, eventType):
    groupId = eventData.get('groupId')
    if not groupId: return
    
    allowed_groups = load_allowed_groups()
    if groupId not in allowed_groups: return
    
    try:
        group_type_val = self.fetchGroupInfo(groupId).gridInfoMap[groupId].type
        group_type_name = "Cộng Đồng" if group_type_val == 2 else "Nhóm"
    except:
        group_type_name = "Nhóm"
        
    groupName = eventData.get('groupName', "Group")
    
    if eventType == GroupEventType.JOIN:
        joinMembers = eventData.get('updateMembers', [])
        sourceId = eventData.get("sourceId")
        event_time = datetime.now()
        
        adder_name = ""
        if sourceId:
            adder_info = self.fetchUserInfo(sourceId) or {}
            if isinstance(adder_info, dict):
                ad = adder_info.get(sourceId, adder_info.get('changed_profiles', {}).get(sourceId, {}))
                adder_name = ad.get('displayName') or ad.get('zaloName') or ""

        with concurrent.futures.ThreadPoolExecutor() as executor:
            for member in joinMembers:
                member_id = member.get('id')
                user_name = member.get('dName', '')
                
                if not adder_name or sourceId == member_id:
                    author_text = "Tham gia trực tiếp hoặc được mời"
                else:
                    author_text = f"Duyệt bởi {adder_name}"
                    
                message_info = {
                    'title': groupName,
                    'userName': f"Chào mừng {user_name}",
                    'subtitle': f"Đã tham gia {group_type_name}",
                    'author': author_text,
                    'fallbackName': user_name
                }
                
                filename = f"welcome_{event_time.timestamp()}.png"
                executor.submit(process_group_event_image, self, member_id, message_info, groupId, event_time, filename, "welcome")
                
    elif eventType in {GroupEventType.LEAVE, GroupEventType.REMOVE_MEMBER}:
        updateMembers = eventData.get('updateMembers', [])
        sourceId = eventData.get("sourceId")
        event_time = datetime.now()
        
        remover_name = "Ai Đó"
        if sourceId:
            remover_info = self.fetchUserInfo(sourceId) or {}
            if isinstance(remover_info, dict):
                rd = remover_info.get(sourceId, remover_info.get('changed_profiles', {}).get(sourceId, {}))
                remover_name = rd.get('displayName') or rd.get('zaloName') or "Ai Đó"

            with concurrent.futures.ThreadPoolExecutor() as executor:
                for member in updateMembers:
                    member_id = member.get('id')
                    user_name = member.get('dName', '')
                    
                    if eventType == GroupEventType.LEAVE:
                        file_type = "goodbye"
                        message_info = {
                            'title': "Member Left The Group",
                            'userName': user_name,
                            'subtitle': f"Vừa rời khỏi {group_type_name}",
                            'author': groupName,
                            'fallbackName': user_name
                        }
                    else:
                        file_type = "kicked"
                        message_info = {
                            'title': "Kicked Out Member",
                            'userName': f"Thằng Oắt Con {user_name}",
                            'subtitle': f"Đã Bị {remover_name} Sút Khỏi {group_type_name}",
                            'author': groupName,
                            'fallbackName': user_name
                        }
                        
                    filename = f"{file_type}_{event_time.timestamp()}.png"
                    executor.submit(process_group_event_image, self, member_id, message_info, groupId, event_time, filename, file_type)
                    
    elif eventType == GroupEventType.ADD_ADMIN:
        updateMembers = eventData.get('updateMembers', [])
        sourceId = eventData.get("sourceId")
        event_time = datetime.now()
        ow_name = "Ai Đó"
        if sourceId:
            ow_info = self.fetchUserInfo(sourceId) or {}
            if isinstance(ow_info, dict):
                od = ow_info.get(sourceId, ow_info.get('changed_profiles', {}).get(sourceId, {}))
                ow_name = od.get('displayName') or od.get('zaloName') or "Ai Đó"

        with concurrent.futures.ThreadPoolExecutor() as executor:
            for member in updateMembers:
                member_id = member.get('id')
                user_name = member.get('dName', '')
                message_info = {
                    'title': groupName,
                    'userName': f"Đại Ca {user_name}",
                    'subtitle': "Vừa Trở Thành Quản Trị Viên",
                    'author': f"Bổ nhiệm bởi {ow_name}",
                    'fallbackName': user_name
                }
                filename = f"add_admin_{event_time.timestamp()}.png"
                executor.submit(process_group_event_image, self, member_id, message_info, groupId, event_time, filename, "add_admin")

    elif eventType == GroupEventType.REMOVE_ADMIN:
        updateMembers = eventData.get('updateMembers', [])
        sourceId = eventData.get("sourceId")
        event_time = datetime.now()
        ow_name = "Ai Đó"
        if sourceId:
            ow_info = self.fetchUserInfo(sourceId) or {}
            if isinstance(ow_info, dict):
                od = ow_info.get(sourceId, ow_info.get('changed_profiles', {}).get(sourceId, {}))
                ow_name = od.get('displayName') or od.get('zaloName') or "Ai Đó"

        with concurrent.futures.ThreadPoolExecutor() as executor:
            for member in updateMembers:
                member_id = member.get('id')
                user_name = member.get('dName', '')
                message_info = {
                    'title': "Removed Admin",
                    'userName': user_name,
                    'subtitle': "Mất Quyền Quản Trị Viên",
                    'author': f"Bởi {ow_name}",
                    'fallbackName': user_name
                }
                filename = f"remove_admin_{event_time.timestamp()}.png"
                executor.submit(process_group_event_image, self, member_id, message_info, groupId, event_time, filename, "remove_admin")

def PTA():
    return {}
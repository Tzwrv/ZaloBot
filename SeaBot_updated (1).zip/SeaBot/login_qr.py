# -*- coding: UTF-8 -*-
"""
login_qr.py — Dang nhap lai bang QR va TU DONG cap nhat IMEI + SESSION_COOKIES
trong config.py. Chi can chay 1 lan khi thay loi:

    'NoneType' object is not subscriptable
    (hoac bat ky loi login nao khac lien quan cookie het han)

Cach dung:
    py login_qr.py

Sau khi quet QR thanh cong, config.py se duoc cap nhat tu dong.
Chay lai:
    py main.py
"""
import os
import re
import sys

from zlapi import ZaloAPI


CONFIG_PATH = "config.py"
QR_IMAGE_PATH = "qr_login.png"


def _open_image(path):
    try:
        if os.name == "nt":
            os.startfile(path)
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}"')
    except Exception:
        pass
    print(f"\n>> Anh QR da luu tai: {os.path.abspath(path)}")
    print(">> Mo app Zalo tren dien thoai -> Quet QR de dang nhap.\n")


def update_config(cookies: dict, imei: str):
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    content = re.sub(
        r'IMEI\s*=\s*".*?"',
        f'IMEI = "{imei}"',
        content,
        count=1,
    )
    content = re.sub(
        r"SESSION_COOKIES\s*=\s*\{.*?\}\n",
        f"SESSION_COOKIES = {cookies!r}\n",
        content,
        count=1,
        flags=re.DOTALL,
    )

    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write(content)


def main():
    print("=" * 60)
    print("  DANG NHAP LAI BANG QR - CAP NHAT SESSION MOI")
    print("=" * 60)

    client = ZaloAPI(phone=None, password=None, imei=None, auto_login=False)

    try:
        result = client.loginWithQR(qr_path=QR_IMAGE_PATH, on_qr_generated=_open_image)
    except Exception as e:
        print(f"\n[LOI] Dang nhap QR that bai: {e}")
        sys.exit(1)
    finally:
        if os.path.exists(QR_IMAGE_PATH):
            try:
                os.remove(QR_IMAGE_PATH)
            except Exception:
                pass

    if not result or result.get("status") != "success":
        print("\n[LOI] Khong nhan duoc phien dang nhap hop le.")
        sys.exit(1)

    user_info = result.get("userInfo", {})
    print(f"\n[OK] Dang nhap thanh cong voi tai khoan: {user_info.get('name', 'Khong ro ten')}")

    cookies = client._state.get_cookies()
    imei = client._state.user_imei

    if not cookies or not imei:
        print("\n[LOI] Khong lay duoc cookies/imei tu phien dang nhap. Thu lai lan nua.")
        sys.exit(1)

    update_config(cookies, imei)
    print(f"\n[OK] Da cap nhat IMEI + SESSION_COOKIES moi vao {CONFIG_PATH}")
    print("[OK] Bay gio chay lai:  py main.py\n")


if __name__ == "__main__":
    main()

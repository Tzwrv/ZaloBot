import json

def read_setting_value(key):
    try:
        with open('seting.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        return settings.get(key)
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy file seting.json. Sử dụng giá trị mặc định cho {key}.")
        return None
    except json.JSONDecodeError:
        print(f"Lỗi: File seting.json không hợp lệ. Sử dụng giá trị mặc định cho {key}.")
        return None

def read_prefix():
    return read_setting_value('prefix') or "?"

def read_admin():
    return read_setting_value('admin') or "636478474544060463"

IMEI = "0e1f2bde-1206-4d25-94c4-e867d9339988-91e1a2a41c0741f7f47615ab9de2fb8a"
SESSION_COOKIES = {"_ga_YT9TMXZYV9":"GS2.1.s1774449587$o1$g0$t1774449591$j56$l0$h0","_ga_1J0YGQPT22":"GS2.1.s1774449602$o1$g0$t1774449608$j54$l0$h0","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WxdE-dcKjRYt6TwQ3GGbYFSf3bfpOq.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8WxdE-dcKjRYt6TwQ3GGbYFSf3bfpOq.1","_ga_RYD7END4JE":"GS2.2.s1779602285$o2$g1$t1779602287$j58$l0$h0","_ga_YS1V643LGV":"GS2.1.s1785826535$o3$g0$t1785826537$j58$l0$h0","_zlang":"vn","_ga":"GA1.2.153144340.1774449587","_gid":"GA1.2.645024308.1785826541","_ga_3EM8ZPYYN3":"GS2.2.s1785826541$o5$g0$t1785826541$j60$l0$h0","zpsid":"Jte4.455236010.24.wZuNTDVMYfnzZwY7szQAdAAb-AZYuxYluUQxhCoJMKWyQCmGrjC7xRtMYfm","zpw_sek":"CtaY.455236010.a0.pz7EDl588aHoFQSf-MI5CgD6u5dwNgSAkWth2empn4gVFjy4bGdoVfapudIlMRWGfN_0uGoFEtHKPO2_gGw5CW","app.event.zalo.me":"1607940871187327961"}
HEADER_STYLE = """Dương Vy"""
API_KEY = 'api_key'
SECRET_KEY = 'secret_key'
ADMIN = read_admin()
ADM = read_admin()
PREFIX = read_prefix()
GEMINI_API_KEY = "AIzaSyBiKqIS4xlwQHMlsv7MLzeRoYl_5ppal"
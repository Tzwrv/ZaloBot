# modules/banner.py - Tạo ảnh menu hiện đại
import os, time

def _draw_banner(user_name, menu_num, items, subtitle, accent_rgb):
    from PIL import Image, ImageDraw, ImageFont
    W, H = 960, 580
    img = Image.new("RGB", (W, H), (8, 8, 20))
    draw = ImageDraw.Draw(img, "RGBA")
    ar, ag, ab = accent_rgb

    # === BG gradient ===
    for y in range(H):
        t = y/H
        r = int(8 + t*15)
        g = int(8 + t*12)
        b = int(20 + t*25)
        draw.line([(0,y),(W,y)], fill=(r,g,b))

    # === Decorative circles ===
    for cx,cy,cr,al in [(780,80,120,18),(150,480,90,15),(500,300,200,8)]:
        for ri in range(cr,0,-8):
            a = int(al*(ri/cr))
            draw.ellipse([cx-ri,cy-ri,cx+ri,cy+ri], fill=(ar,ag,ab,a))

    # === Grid lines ===
    for x in range(0,W,60):
        draw.line([(x,0),(x,H)], fill=(ar,ag,ab,12))
    for y in range(0,H,60):
        draw.line([(0,y),(W,y)], fill=(ar,ag,ab,12))

    # === Header box ===
    draw.rounded_rectangle([15,15,W-15,105], radius=16, fill=(ar,ag,ab,25), outline=(ar,ag,ab,180), width=2)

    # === Fonts ===
    try:
        ft = ImageFont.truetype("arial.ttf",36)
        fm = ImageFont.truetype("arial.ttf",20)
        fs = ImageFont.truetype("arial.ttf",16)
        fx = ImageFont.truetype("arial.ttf",14)
    except:
        ft=fm=fs=fx=ImageFont.load_default()

    # === Bot name glow ===
    from core import get_bot_name, get_version
    bot_name = get_bot_name()
    for dx in range(-2,3):
        for dy in range(-2,3):
            draw.text((W//2+dx, 35+dy), f"⚡ {bot_name} ⚡", font=ft, fill=(ar,ag,ab,40), anchor="mt")
    draw.text((W//2, 35), f"⚡ {bot_name} ⚡", font=ft, fill=(ar,ag,ab,255), anchor="mt")
    draw.text((W//2, 78), f"v{get_version()}  •  {subtitle}  •  Xin chào, {user_name}!", font=fx, fill=(200,220,255,200), anchor="mt")

    # === Menu label ===
    label = f"MENU {menu_num}"
    lw = draw.textlength(label, font=fm)
    draw.rounded_rectangle([W//2-lw//2-20, 108, W//2+lw//2+20, 138], radius=8, fill=(ar,ag,ab,200))
    draw.text((W//2, 123), label, font=fm, fill=(10,10,20,255), anchor="mm")

    # === Items grid ===
    cols = 2
    rows_per_col = (len(items)+cols-1)//cols
    col_w = (W-50)//cols
    start_y = 148

    for i, (icon, cmd, desc) in enumerate(items):
        col = i % cols
        row = i // cols
        x = 25 + col*col_w
        y = start_y + row*52

        # Row bg alternating
        if (i//cols) % 2 == 0:
            draw.rounded_rectangle([x,y,x+col_w-10,y+46], radius=8, fill=(ar,ag,ab,15))
        else:
            draw.rounded_rectangle([x,y,x+col_w-10,y+46], radius=8, fill=(255,255,255,8))

        # Bullet dot
        draw.ellipse([x+10,y+18,x+18,y+26], fill=(ar,ag,ab,230))

        # Icon + command
        draw.text((x+26, y+8), f"{icon} {cmd}", font=fs, fill=(ar,ag,ab,255))
        # Description
        draw.text((x+26, y+28), desc, font=fx, fill=(170,200,240,200))

    # === Footer ===
    from core import get_prefix
    p = get_prefix()
    draw.rounded_rectangle([15,H-50,W-15,H-12], radius=10, fill=(ar,ag,ab,30), outline=(ar,ag,ab,80), width=1)
    draw.text((W//2, H-31), f"💡 Gõ {p}menu1 ~ {p}menu5 để xem thêm  |  {p}help để trợ giúp", font=fx, fill=(150,200,255,180), anchor="mm")

    # Save
    os.makedirs("cache", exist_ok=True)
    path = f"cache/menu{menu_num}_{int(time.time())}.png"
    img.save(path, "PNG")
    return path


MENU_DATA = {
    1: {
        "subtitle": "📋 Tổng Quan",
        "accent": (0, 200, 255),
        "items": [
            ("📋","!menu1","Tổng quan lệnh"),
            ("🎮","!menu2","Giải trí & Games"),
            ("🔧","!menu3","Tiện ích & Tools"),
            ("👮","!menu4","Quản lý nhóm"),
            ("🛡️","!menu5","Anti & Bảo vệ"),
            ("🏓","!ping","Kiểm tra bot"),
            ("ℹ️","!info","Thông tin bot"),
            ("⏱️","!uptime","Thời gian hoạt động"),
            ("👤","!tôi","Thông tin bạn"),
            ("🆔","!uid","Xem UID Zalo"),
            ("🏠","!idnhom","ID nhóm hiện tại"),
            ("👥","!thanhvien","Danh sách thành viên"),
            ("⚙️","!prefix","Xem prefix hiện tại"),
            ("🤖","!bot","Thông tin bot chi tiết"),
        ]
    },
    2: {
        "subtitle": "🎮 Giải Trí",
        "accent": (255, 100, 200),
        "items": [
            ("🎲","!taixiu [t/x]","Chơi tài xỉu"),
            ("🎰","!xocdia [c/l]","Chơi xóc đĩa"),
            ("🔮","!boi","Bói toán hôm nay"),
            ("💘","!love [tên]","Test tình duyên"),
            ("💞","!ship @a @b","Ship 2 người"),
            ("😂","!joke","Chuyện cười"),
            ("🎱","!8ball [câu]","Hỏi thần 8ball"),
            ("⚔️","!war @người","Chiến với ai đó"),
            ("🔥","!roast @người","Roast ai đó"),
            ("🎯","!chuoiso [n]","Đoán số may mắn"),
            ("🃏","!card","Rút bài ngẫu nhiên"),
            ("🏆","!rank","Xem bảng xếp hạng"),
            ("💀","!truth","Thách thức sự thật"),
            ("🎭","!dare","Thách thức hành động"),
        ]
    },
    3: {
        "subtitle": "🔧 Tiện Ích",
        "accent": (100, 255, 150),
        "items": [
            ("🌐","!dich [text]","Dịch sang tiếng Anh"),
            ("🇻🇳","!dichvi [text]","Dịch sang tiếng Việt"),
            ("🌤️","!weather [tp]","Xem thời tiết"),
            ("📚","!wiki [từ]","Tra Wikipedia"),
            ("📲","!qr [nội dung]","Tạo QR code"),
            ("💱","!tygia","Tỷ giá ngoại tệ"),
            ("🌐","!ip [địa chỉ]","Tra thông tin IP"),
            ("🧮","!calc [biểu thức]","Máy tính"),
            ("📰","!news","Tin tức mới nhất"),
            ("🔑","!pass [độ dài]","Tạo mật khẩu ngẫu nhiên"),
            ("🎨","!textart [text]","Chuyển text nghệ thuật"),
            ("🔢","!random [min] [max]","Số ngẫu nhiên"),
            ("⏰","!time [thành phố]","Xem giờ thế giới"),
            ("📏","!base64 [text]","Mã hóa Base64"),
        ]
    },
    4: {
        "subtitle": "👮 Quản Lý",
        "accent": (255, 180, 0),
        "items": [
            ("👢","!kick @người","Kick thành viên"),
            ("🔇","!mute @người","Cấm chat"),
            ("🔊","!unmute @người","Bỏ cấm chat"),
            ("📢","!tagall [msg]","Tag tất cả"),
            ("📌","!pin [msg]","Ghim tin nhắn"),
            ("🚪","!leave","Bot rời nhóm"),
            ("👋","!welcome on/off","Bật/tắt chào mừng"),
            ("📣","!broadcast [msg]","Gửi tất cả nhóm"),
            ("👑","!addadmin @","Thêm admin bot"),
            ("❌","!rmadmin @","Xoá admin bot"),
            ("⚙️","!setprefix [ký tự]","Đổi prefix"),
            ("📊","!info nhóm","Thông tin nhóm"),
            ("🔄","!restart","Khởi động lại bot"),
            ("📋","!listadmin","Danh sách admin bot"),
        ]
    },
    5: {
        "subtitle": "🛡️ Bảo Vệ",
        "accent": (255, 80, 80),
        "items": [
            ("🛡️","!anti","Xem trạng thái anti"),
            ("🚫","!antispam on/off","Chặn spam tin nhắn"),
            ("🚫","!antisticker on/off","Chặn sticker"),
            ("🚫","!antiphoto on/off","Chặn ảnh"),
            ("🚫","!antivideo on/off","Chặn video"),
            ("🚫","!antifile on/off","Chặn file"),
            ("🚫","!antilink on/off","Chặn link"),
            ("🚫","!anticontact on/off","Chặn danh thiếp"),
            ("📊","!spamlog","Xem log spam"),
            ("🧹","!clearlog","Xoá log spam"),
            ("⚠️","!warn @người","Cảnh cáo thành viên"),
            ("📜","!warnlist","Danh sách cảnh cáo"),
            ("🔒","!lockgroup","Khoá nhóm"),
            ("🔓","!unlockgroup","Mở khoá nhóm"),
        ]
    }
}


def generate_menu_image(menu_num, user_name="Bạn"):
    try:
        data = MENU_DATA.get(menu_num, MENU_DATA[1])
        return _draw_banner(user_name, menu_num, data["items"], data["subtitle"], data["accent"])
    except Exception as e:
        print(f"[BANNER ERR] {e}")
        return None

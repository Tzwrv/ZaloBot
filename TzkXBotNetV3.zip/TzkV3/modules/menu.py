# modules/menu.py v3
import os
from core import get_prefix, get_bot_name, get_version, get_user_name
from zlapi.models import Message

def _send_menu(bot, mo, aid, tid, tt, num):
    name = get_user_name(bot, aid)
    p = get_prefix()
    try:
        from modules.banner import generate_menu_image
        path = generate_menu_image(num, name)
        if path and os.path.exists(path):
            labels = {1:"📋 Tổng Quan",2:"🎮 Giải Trí",3:"🔧 Tiện Ích",4:"👮 Quản Lý",5:"🛡️ Bảo Vệ"}
            bot.sendLocalImage(path, thread_id=tid, thread_type=tt,
                message=Message(text=f"🤖 {get_bot_name()} v{get_version()} | {labels.get(num,'')} | Xin chào {name}!"))
            try: os.remove(path)
            except: pass
            return
    except Exception as e:
        print(f"[MENU IMG ERR] {e}")

    # Fallback text
    menus = {
        1: f"📋 MENU 1 - TỔNG QUAN\n{'─'*28}\n{p}menu1~{p}menu5 | {p}ping | {p}info\n{p}tôi | {p}uid | {p}idnhom | {p}prefix",
        2: f"🎮 MENU 2 - GIẢI TRÍ\n{'─'*28}\n{p}taixiu | {p}xocdia | {p}boi | {p}love\n{p}ship | {p}joke | {p}8ball | {p}war\n{p}roast | {p}card | {p}truth | {p}dare",
        3: f"🔧 MENU 3 - TIỆN ÍCH\n{'─'*28}\n{p}dich | {p}dichvi | {p}weather | {p}wiki\n{p}qr | {p}tygia | {p}ip | {p}calc\n{p}news | {p}pass | {p}random | {p}time",
        4: f"👮 MENU 4 - QUẢN LÝ\n{'─'*28}\n{p}kick | {p}mute | {p}unmute | {p}tagall\n{p}pin | {p}leave | {p}broadcast\n{p}addadmin | {p}rmadmin | {p}setprefix",
        5: f"🛡️ MENU 5 - BẢO VỆ\n{'─'*28}\n{p}anti | {p}antispam | {p}antisticker\n{p}antiphoto | {p}antivideo | {p}antifile\n{p}antilink | {p}anticontact | {p}warn",
    }
    bot.replyMessage(Message(text=menus.get(num, menus[1])), mo, tid, tt)

def handle_menu1(bot, mo, aid, tid, tt): _send_menu(bot, mo, aid, tid, tt, 1)
def handle_menu2(bot, mo, aid, tid, tt): _send_menu(bot, mo, aid, tid, tt, 2)
def handle_menu3(bot, mo, aid, tid, tt): _send_menu(bot, mo, aid, tid, tt, 3)
def handle_menu4(bot, mo, aid, tid, tt): _send_menu(bot, mo, aid, tid, tt, 4)
def handle_menu5(bot, mo, aid, tid, tt): _send_menu(bot, mo, aid, tid, tt, 5)

def handle_menu(bot, mo, aid, tid, tt):
    # Send menu 1 as default, then hint others
    _send_menu(bot, mo, aid, tid, tt, 1)
    p = get_prefix()
    bot.replyMessage(
        Message(text=f"📌 Xem thêm: {p}menu2 🎮 | {p}menu3 🔧 | {p}menu4 👮 | {p}menu5 🛡️"),
        mo, tid, tt
    )

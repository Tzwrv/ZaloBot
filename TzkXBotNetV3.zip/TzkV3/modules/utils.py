import requests, random, string, time, base64
from core import get_user_name
from zlapi.models import Message

def handle_translate(bot, mo, aid, tid, tt, args, lang="en"):
    if not args: bot.replyMessage(Message(text=f"❌ !dich [văn bản]"), mo, tid, tt); return
    text=" ".join(args)
    try:
        url=f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={lang}&dt=t&q={requests.utils.quote(text)}"
        r=requests.get(url,timeout=10); result=r.json()[0][0][0]
        ln="Tiếng Anh" if lang=="en" else "Tiếng Việt"
        bot.replyMessage(Message(text=f"🌐 Dịch → {ln}:\n📝 {text}\n✅ {result}"), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi dịch: {e}"), mo, tid, tt)

def handle_weather(bot, mo, aid, tid, tt, args):
    city=" ".join(args) if args else "Ho Chi Minh"
    try:
        r=requests.get(f"https://wttr.in/{requests.utils.quote(city)}?format=j1",timeout=10)
        d=r.json(); c=d["current_condition"][0]
        uv=int(c.get("uvIndex","0"))
        uv_label="Thấp🟢" if uv<=2 else "Trung bình🟡" if uv<=5 else "Cao🔴"
        text=f"""🌤️ THỜI TIẾT: {city.upper()}
{'─'*28}
🌡️ Nhiệt độ : {c['temp_C']}°C (cảm giác {c['FeelsLikeC']}°C)
💧 Độ ẩm   : {c['humidity']}%
🌬️ Gió     : {c['windspeedKmph']} km/h
☁️ Trời    : {c['weatherDesc'][0]['value']}
☀️ UV      : {uv} ({uv_label})"""
        bot.replyMessage(Message(text=text), mo, tid, tt)
    except:
        bot.replyMessage(Message(text=f"❌ Không tìm được thời tiết '{city}'"), mo, tid, tt)

def handle_wiki(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !wiki [từ khoá]"), mo, tid, tt); return
    kw=" ".join(args)
    try:
        r=requests.get(f"https://vi.wikipedia.org/api/rest_v1/page/summary/{requests.utils.quote(kw)}",timeout=10)
        d=r.json()
        if "extract" not in d: bot.replyMessage(Message(text=f"❌ Không tìm thấy '{kw}'"), mo, tid, tt); return
        extract=d["extract"][:400]; url=d.get("content_urls",{}).get("desktop",{}).get("page","")
        bot.replyMessage(Message(text=f"📚 {d['title']}\n\n{extract}...\n\n🔗 {url}"), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi: {e}"), mo, tid, tt)

def handle_qr(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !qr [nội dung]"), mo, tid, tt); return
    content=" ".join(args)
    qr_url=f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={requests.utils.quote(content)}"
    try:
        bot.sendRemoteImage(qr_url, thread_id=tid, thread_type=tt, message=Message(text=f"📲 QR: {content}"))
    except:
        bot.replyMessage(Message(text=f"🔗 QR URL:\n{qr_url}"), mo, tid, tt)

def handle_tygia(bot, mo, aid, tid, tt, args):
    try:
        r=requests.get("https://api.exchangerate-api.com/v4/latest/USD",timeout=10)
        d=r.json()["rates"]
        vnd=d.get("VND",0); eur=d.get("EUR",1); jpy=d.get("JPY",1); gbp=d.get("GBP",1); krw=d.get("KRW",1)
        text=f"""💱 TỶ GIÁ NGOẠI TỆ
{'─'*28}
💵 1 USD = {vnd:,.0f} VND
💶 1 EUR = {vnd/eur:,.0f} VND
💴 1 JPY = {vnd/jpy:,.0f} VND
💷 1 GBP = {vnd/gbp:,.0f} VND
🇰🇷 1 KRW = {vnd/krw:,.0f} VND"""
        bot.replyMessage(Message(text=text), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi: {e}"), mo, tid, tt)

def handle_ip(bot, mo, aid, tid, tt, args):
    ip=args[0] if args else None
    try:
        url=f"https://ipapi.co/{ip}/json/" if ip else "https://ipapi.co/json/"
        d=requests.get(url,timeout=10).json()
        text=f"""🌐 THÔNG TIN IP: {d.get('ip','N/A')}
{'─'*28}
🌍 Quốc gia : {d.get('country_name','N/A')}
🏙️ Thành phố: {d.get('city','N/A')}
🗺️ Vùng    : {d.get('region','N/A')}
📡 ISP      : {d.get('org','N/A')}
⏰ Giờ địa phương: {d.get('utc_offset','N/A')}"""
        bot.replyMessage(Message(text=text), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi: {e}"), mo, tid, tt)

def handle_calc(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !calc [biểu thức]\nVD: !calc 2+2*3"), mo, tid, tt); return
    expr=" ".join(args)
    try:
        allowed=set("0123456789+-*/.() ")
        if not all(c in allowed for c in expr): raise ValueError("Ký tự không hợp lệ")
        result=eval(compile(expr,"<string>","eval"))
        bot.replyMessage(Message(text=f"🧮 {expr} = {result}"), mo, tid, tt)
    except:
        bot.replyMessage(Message(text="❌ Biểu thức không hợp lệ!\nVD: !calc 10+5*2-3/1"), mo, tid, tt)

def handle_news(bot, mo, aid, tid, tt, args):
    try:
        import xml.etree.ElementTree as ET
        r=requests.get("https://vnexpress.net/rss/tin-moi-nhat.rss",timeout=10)
        root=ET.fromstring(r.content)
        items=root.findall(".//item")[:5]
        text="📰 TIN TỨC MỚI NHẤT (VnExpress)\n"+"─"*28
        for i,item in enumerate(items,1):
            title=item.find("title").text or ""
            link=item.find("link").text or ""
            text+=f"\n\n{i}. {title}"
        bot.replyMessage(Message(text=text), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi tải tin tức: {e}"), mo, tid, tt)

def handle_password(bot, mo, aid, tid, tt, args):
    try:
        length=int(args[0]) if args else 12
        length=max(6,min(32,length))
        chars=string.ascii_letters+string.digits+"!@#$%^&*"
        pwd="".join(random.choices(chars,k=length))
        bot.replyMessage(Message(text=f"🔑 Mật khẩu ({length} ký tự):\n{pwd}\n\n⚠️ Hãy lưu lại ngay!"), mo, tid, tt)
    except:
        bot.replyMessage(Message(text="❌ !pass [độ dài] (6-32)"), mo, tid, tt)

def handle_base64(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !base64 [text]"), mo, tid, tt); return
    text=" ".join(args)
    try:
        encoded=base64.b64encode(text.encode()).decode()
        bot.replyMessage(Message(text=f"🔐 Base64:\n{encoded}"), mo, tid, tt)
    except:
        bot.replyMessage(Message(text="❌ Lỗi mã hóa!"), mo, tid, tt)

def handle_time_world(bot, mo, aid, tid, tt, args):
    import datetime
    zones={
        "việt nam":7,"hà nội":7,"hcm":7,"nhật":9,"nhật bản":9,"hàn":9,"hàn quốc":9,
        "mỹ":-5,"new york":-5,"anh":0,"london":0,"pháp":1,"paris":1,
        "úc":10,"sydney":10,"singapore":8,"trung quốc":8,"beijing":8
    }
    city=" ".join(args).lower() if args else "việt nam"
    offset=zones.get(city,7)
    utc=datetime.datetime.utcnow()
    local=utc+datetime.timedelta(hours=offset)
    bot.replyMessage(Message(text=f"⏰ Giờ tại {city.title()}:\n{local.strftime('%H:%M:%S %d/%m/%Y')}\n(UTC{'+' if offset>=0 else ''}{offset})"), mo, tid, tt)

def handle_textart(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !textart [text]"), mo, tid, tt); return
    text=" ".join(args)
    styles=["𝗕𝗼𝗹𝗱","𝘐𝘵𝘢𝘭𝘪𝘤","𝙱𝚘𝚕𝚍 𝙼𝚘𝚗𝚘","𝕾𝖊𝖗𝖎𝖋","𝔉𝔯𝔞𝔨𝔱𝔲𝔯"]
    # Simple style mappings
    normal="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    bold  ="𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵"
    result=""
    for ch in text:
        idx=normal.find(ch)
        result+=bold[idx] if idx>=0 and idx<len(bold) else ch
    bot.replyMessage(Message(text=f"✨ Text nghệ thuật:\n{result}"), mo, tid, tt)

import time
from core import is_admin, get_user_name, add_admin, remove_admin, save_config, load_config, get_anti, set_anti, load_json, save_json
from zlapi.models import Message, ThreadType

def req_admin(bot, mo, aid, tid, tt):
    if not is_admin(aid):
        bot.replyMessage(Message(text="🔒 Chỉ Admin Bot mới dùng được!"), mo, tid, tt); return False
    return True

# ── KICK ─────────────────────────────────────────────────────────
def handle_kick(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    if tt!=ThreadType.GROUP: bot.replyMessage(Message(text="❌ Chỉ dùng trong nhóm!"),mo,tid,tt); return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !kick @người"),mo,tid,tt); return
    for m in mentions:
        try: bot.removeUsersFromGroup(m.uid,tid); bot.replyMessage(Message(text=f"✅ Đã kick {get_user_name(bot,m.uid)}!"),mo,tid,tt)
        except Exception as e: bot.replyMessage(Message(text=f"❌ Lỗi: {e}"),mo,tid,tt)

# ── MUTE/UNMUTE ──────────────────────────────────────────────────
def _load_muted(): return load_json("cache/muted.json",{})
def _save_muted(d): save_json("cache/muted.json",d)
def is_muted(uid,tid): return str(uid) in [str(u) for u in _load_muted().get(str(tid),[])]

def handle_mute(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !mute @người"),mo,tid,tt); return
    muted=_load_muted()
    for m in mentions:
        muted.setdefault(str(tid),[])
        if str(m.uid) not in muted[str(tid)]: muted[str(tid)].append(str(m.uid))
        bot.replyMessage(Message(text=f"🔇 Đã mute {get_user_name(bot,m.uid)}!"),mo,tid,tt)
    _save_muted(muted)

def handle_unmute(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !unmute @người"),mo,tid,tt); return
    muted=_load_muted()
    for m in mentions:
        if str(tid) in muted and str(m.uid) in muted[str(tid)]: muted[str(tid)].remove(str(m.uid))
        bot.replyMessage(Message(text=f"🔊 Đã unmute {get_user_name(bot,m.uid)}!"),mo,tid,tt)
    _save_muted(muted)

# ── TAGALL ───────────────────────────────────────────────────────
def handle_tagall(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    if tt!=ThreadType.GROUP: bot.replyMessage(Message(text="❌ Chỉ dùng trong nhóm!"),mo,tid,tt); return
    try:
        gi=bot.fetchGroupInfo(tid); grid=gi.gridInfoMap.get(tid)
        members=getattr(grid,"memVerList",[]) or []
        msg=" ".join(args) if args else "📢 Thông báo!"
        tag_text=f"📢 {msg}\n"+" ".join([f"@{uid}" for uid in members[:50]])
        bot.replyMessage(Message(text=tag_text),mo,tid,tt)
    except Exception as e: bot.replyMessage(Message(text=f"❌ Lỗi: {e}"),mo,tid,tt)

# ── ADMIN MANAGEMENT ─────────────────────────────────────────────
def handle_addadmin(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !addadmin @người"),mo,tid,tt); return
    for m in mentions:
        if add_admin(m.uid): bot.replyMessage(Message(text=f"✅ Đã thêm {get_user_name(bot,m.uid)} làm Admin!"),mo,tid,tt)
        else: bot.replyMessage(Message(text="⚠️ Đã là Admin rồi!"),mo,tid,tt)

def handle_rmadmin(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !rmadmin @người"),mo,tid,tt); return
    for m in mentions:
        remove_admin(m.uid); bot.replyMessage(Message(text=f"✅ Đã xoá quyền Admin {get_user_name(bot,m.uid)}!"),mo,tid,tt)

def handle_setprefix(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    if not args: bot.replyMessage(Message(text="❌ !setprefix [ký tự]"),mo,tid,tt); return
    cfg=load_config(); cfg["prefix"]=args[0]; save_config(cfg)
    bot.replyMessage(Message(text=f"✅ Đã đổi prefix → {args[0]}"),mo,tid,tt)

def handle_broadcast(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    if not args: bot.replyMessage(Message(text="❌ !broadcast [nội dung]"),mo,tid,tt); return
    msg=" ".join(args)
    try:
        gs=bot.fetchAllGroups(); gids=list(gs.gridVerMap.keys()); count=0
        for gid in gids:
            try: bot.send(Message(text=f"📢 THÔNG BÁO:\n\n{msg}"),gid,ThreadType.GROUP); count+=1
            except: pass
        bot.replyMessage(Message(text=f"✅ Đã gửi {count}/{len(gids)} nhóm!"),mo,tid,tt)
    except Exception as e: bot.replyMessage(Message(text=f"❌ Lỗi: {e}"),mo,tid,tt)

def handle_leave(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    try: bot.replyMessage(Message(text="👋 Bot rời nhóm! Tạm biệt!"),mo,tid,tt); bot.leaveGroup(tid)
    except Exception as e: bot.replyMessage(Message(text=f"❌ Lỗi: {e}"),mo,tid,tt)

# ── WARN ─────────────────────────────────────────────────────────
def _load_warns(): return load_json("cache/warns.json",{})
def _save_warns(d): save_json("cache/warns.json",d)

def handle_warn(bot, mo, aid, tid, tt, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    mentions=getattr(mo,"mentions",None)
    if not mentions: bot.replyMessage(Message(text="❌ !warn @người [lý do]"),mo,tid,tt); return
    warns=_load_warns()
    for m in mentions:
        uid=str(m.uid); warns.setdefault(tid,{}).setdefault(uid,0)
        warns[tid][uid]+=1; count=warns[tid][uid]
        reason=" ".join(args) if args else "Không có lý do"
        name=get_user_name(bot,m.uid)
        bot.replyMessage(Message(text=f"⚠️ CẢNH CÁO #{count}\n👤 {name}\n📝 Lý do: {reason}\n{'🚫 AUTO KICK!' if count>=3 else f'⚠️ Còn {3-count} lần nữa sẽ bị kick!'}"),mo,tid,tt)
        if count>=3:
            try: bot.removeUsersFromGroup(m.uid,tid); warns[tid][uid]=0
            except: pass
    _save_warns(warns)

def handle_warnlist(bot, mo, aid, tid, tt):
    warns=_load_warns().get(tid,{})
    if not warns: bot.replyMessage(Message(text="✅ Chưa có ai bị cảnh cáo!"),mo,tid,tt); return
    text="📋 DANH SÁCH CẢNH CÁO\n"+"─"*25
    for uid,cnt in warns.items():
        if cnt>0: text+=f"\n• UID {uid}: {cnt} lần"
    bot.replyMessage(Message(text=text),mo,tid,tt)

# ── ANTI SYSTEM ──────────────────────────────────────────────────
ANTI_KEYS={"antispam":"Chặn spam","antisticker":"Chặn sticker","antiphoto":"Chặn ảnh",
           "antivideo":"Chặn video","antifile":"Chặn file","antilink":"Chặn link",
           "anticontact":"Chặn danh thiếp"}

def handle_anti_status(bot, mo, aid, tid, tt):
    cfg=load_config().get("anti",{})
    text="🛡️ TRẠNG THÁI BẢO VỆ\n"+"─"*25
    for k,label in ANTI_KEYS.items():
        status="🟢 BẬT" if cfg.get(k,False) else "🔴 TẮT"
        text+=f"\n{status} {label} ({k})"
    text+=f"\n\n💡 Dùng: !antispam on/off để bật/tắt"
    bot.replyMessage(Message(text=text),mo,tid,tt)

def handle_anti_toggle(bot, mo, aid, tid, tt, key, args):
    if not req_admin(bot,mo,aid,tid,tt): return
    if not args or args[0].lower() not in ["on","off"]:
        bot.replyMessage(Message(text=f"❌ !{key} on/off"),mo,tid,tt); return
    val=args[0].lower()=="on"; set_anti(key,val)
    label=ANTI_KEYS.get(key,key)
    bot.replyMessage(Message(text=f"{'🟢 BẬT' if val else '🔴 TẮT'} {label}!"),mo,tid,tt)

# ── SPAM TRACKING ────────────────────────────────────────────────
spam_tracker={}
def check_spam(uid, tid):
    key=f"{tid}_{uid}"; now=time.time()
    if key not in spam_tracker: spam_tracker[key]=[]
    spam_tracker[key]=[t for t in spam_tracker[key] if now-t<10]
    spam_tracker[key].append(now)
    limit=load_config().get("anti",{}).get("spam_limit",5)
    return len(spam_tracker[key])>=limit

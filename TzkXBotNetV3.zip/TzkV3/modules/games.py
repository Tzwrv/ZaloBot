import random, time
from core import get_user_name
from zlapi.models import Message

# ─── TÀI XỈU ─────────────────────────────────────────────────────
def handle_taixiu(bot, mo, aid, tid, tt, args):
    name=get_user_name(bot,aid)
    dice=[random.randint(1,6) for _ in range(3)]
    total=sum(dice); result="TÀI 🔴" if total>=11 else "XỈU 🔵"
    emo={1:"⚀",2:"⚁",3:"⚂",4:"⚃",5:"⚄",6:"⚅"}
    dstr=" ".join(emo[d] for d in dice)
    if args:
        bet=args[0].lower()
        win=(total>=11) if bet in ["tài","tai","t"] else (total<11) if bet in ["xỉu","xiu","x"] else None
        if win is None: bot.replyMessage(Message(text="❌ !taixiu tài/xỉu"), mo, tid, tt); return
        st="🎉 THẮNG!" if win else "😢 THUA!"
        bot.replyMessage(Message(text=f"🎲 {name} cược: {bet.upper()}\n{dstr}\nTổng {total} → {result}\n{st}"), mo, tid, tt)
    else:
        bot.replyMessage(Message(text=f"🎲 {dstr}\nTổng: {total} → {result}\nCược: !taixiu tài/xỉu"), mo, tid, tt)

# ─── XÓC ĐĨA ─────────────────────────────────────────────────────
def handle_xocdia(bot, mo, aid, tid, tt, args):
    name=get_user_name(bot,aid)
    coins=[random.choice(["C","N"]) for _ in range(4)]
    chan=coins.count("C"); result="CHẴN ⚪" if chan%2==0 else "LẺ ⚫"
    cstr=" ".join("🟡" if c=="C" else "⚫" for c in coins)
    if args:
        bet=args[0].lower()
        win=(chan%2==0) if bet in ["chẵn","chan","c"] else (chan%2!=0) if bet in ["lẻ","le","l"] else None
        if win is None: bot.replyMessage(Message(text="❌ !xocdia chẵn/lẻ"), mo, tid, tt); return
        st="🎉 THẮNG!" if win else "😢 THUA!"
        bot.replyMessage(Message(text=f"🎰 {name} cược: {bet.upper()}\n{cstr}\nChẵn:{chan} Lẻ:{4-chan} → {result}\n{st}"), mo, tid, tt)
    else:
        bot.replyMessage(Message(text=f"🎰 {cstr}\nChẵn:{chan} Lẻ:{4-chan} → {result}"), mo, tid, tt)

# ─── BÓI ─────────────────────────────────────────────────────────
BOI_LIST=[
    ("✨ Vận may đang mỉm cười với bạn!",5),("💫 Hôm nay là ngày tuyệt vời!",4),
    ("⚠️ Hãy cẩn thận trong các quyết định.",3),("🌟 Tình duyên rất tươi sáng!",5),
    ("💰 Tài lộc đến bất ngờ trong tuần!",4),("🌧️ Kiên trì, khó khăn chỉ tạm thời.",3),
    ("🍀 May mắn đang ở bên bạn!",5),("❌ Chưa phải lúc để hành động lớn.",2),
    ("🔥 Năng lượng cực mạnh hôm nay!",5),("💎 Tin vui sắp đến!",4),
    ("🌈 Mọi việc sẽ tốt hơn!",4),("😌 Hãy giữ bình tĩnh, thành công đến.",3),
]
def handle_boi(bot, mo, aid, tid, tt, args):
    name=get_user_name(bot,aid); msg,stars=random.choice(BOI_LIST)
    sstr="⭐"*stars+"☆"*(5-stars)
    bot.replyMessage(Message(text=f"🔮 Bói cho {name}:\n\n{msg}\n{sstr} ({stars}/5 sao)"), mo, tid, tt)

# ─── LOVE ─────────────────────────────────────────────────────────
def handle_love(bot, mo, aid, tid, tt, args):
    name=get_user_name(bot,aid)
    if not args: bot.replyMessage(Message(text="❌ !love [tên]"), mo, tid, tt); return
    partner=" ".join(args); pct=random.randint(1,100)
    if pct>=85: st="💑 Trời sinh một cặp! Cưới đi!"
    elif pct>=65: st="💕 Khá hợp, hãy cố gắng thêm!"
    elif pct>=45: st="💛 Tạm được, cần thêm thời gian."
    elif pct>=25: st="💔 Ít hợp, khó lâu dài."
    else: st="❌ Không hợp tí nào!"
    bar="❤️"*(pct//10)+"🖤"*(10-pct//10)
    bot.replyMessage(Message(text=f"💘 {name} 💕 {partner}\n{bar}\n💯 {pct}%\n{st}"), mo, tid, tt)

# ─── SHIP ─────────────────────────────────────────────────────────
def handle_ship(bot, mo, aid, tid, tt, args):
    mentions=getattr(mo,"mentions",None)
    if not mentions or len(list(mentions))<2:
        bot.replyMessage(Message(text="❌ !ship @người1 @người2"), mo, tid, tt); return
    ml=list(mentions); n1=get_user_name(bot,ml[0].uid); n2=get_user_name(bot,ml[1].uid)
    pct=random.randint(1,100); bar="💖"*(pct//10)+"🖤"*(10-pct//10)
    bot.replyMessage(Message(text=f"💘 SHIP: {n1} × {n2}\n{bar}\n💯 {pct}% phù hợp!"), mo, tid, tt)

# ─── JOKE ─────────────────────────────────────────────────────────
JOKES=[
    "Tại sao lập trình viên không thích ra ngoài?\nVì ngoài đó không có Wi-Fi! 😂",
    "Bug là gì?\nLà tính năng chưa được document! 😆",
    "Vợ nhắn: Mua 1 ổ bánh mì, có trứng thì mua 6.\nAnh về với 6 ổ vì siêu thị có trứng! 🤦",
    "Code 8 tiếng không bug = Code 8 tiếng chưa test! 🐛",
    "Hỏi: Con gì không có chân mà đi được?\nĐáp: Con đường! 😂",
    "Sao code không chạy?\nVì nó đang đi bộ! 🚶",
    "Lập trình viên khác bác sĩ:\nBác sĩ giết 1 người 1 lần. LTV giết nhiều người cùng lúc = 1 bug! 😱",
    "Tại sao ma không dọa được LTV?\nVì họ quen với bug ban đêm rồi! 👻",
]
def handle_joke(bot, mo, aid, tid, tt):
    bot.replyMessage(Message(text=f"😂 CHUYỆN CƯỜI:\n\n{random.choice(JOKES)}"), mo, tid, tt)

# ─── 8BALL ────────────────────────────────────────────────────────
BALL=["✅ Chắc chắn rồi!","✅ Đúng vậy!","✅ Không nghi ngờ gì!",
      "⚠️ Chưa rõ, hỏi lại sau.","⚠️ Khó nói lúc này.","⚠️ Tập trung rồi hỏi lại.",
      "❌ Đừng hy vọng quá.","❌ Câu trả lời là KHÔNG.","❌ Triển vọng không tốt."]
def handle_8ball(bot, mo, aid, tid, tt, args):
    if not args: bot.replyMessage(Message(text="❌ !8ball [câu hỏi]"), mo, tid, tt); return
    bot.replyMessage(Message(text=f"🎱 {' '.join(args)}\n\n{random.choice(BALL)}"), mo, tid, tt)

# ─── ROAST ────────────────────────────────────────────────────────
ROASTS=["😂 {name} IQ cao đến mức... chia cho 0 cũng được!",
        "🤡 {name} thông minh lắm, nhưng ẩn đi hơi kỹ quá!",
        "💀 {name} sinh ra để làm gì nhỉ... không ai biết!",
        "🗿 {name} trông bình thường, và đúng là bình thường thôi!",
        "😴 {name} chăm chỉ lắm... chăm ngủ nhất nhóm!",
        "🔥 {name} hot lắm, hot như máy tính không có quạt!",
        "🌚 {name} là người hài hước nhất nhóm theo kiểu không ai cười!",]
def handle_roast(bot, mo, aid, tid, tt, args):
    mentions=getattr(mo,"mentions",None)
    uid=list(mentions)[0].uid if mentions else aid
    name=get_user_name(bot,uid)
    bot.replyMessage(Message(text=random.choice(ROASTS).replace("{name}",name)), mo, tid, tt)

# ─── ĐOÁN SỐ ─────────────────────────────────────────────────────
guess_games = {}
def handle_guess(bot, mo, aid, tid, tt, args):
    key=f"{tid}_{aid}"
    if not args:
        num=random.randint(1,100)
        guess_games[key]={"num":num,"tries":0}
        bot.replyMessage(Message(text="🎯 Tui đang nghĩ một số từ 1-100!\nDùng: !guess [số bạn đoán]"), mo, tid, tt)
        return
    if key not in guess_games:
        bot.replyMessage(Message(text="❌ Chưa bắt đầu game! Gõ !guess để bắt đầu"), mo, tid, tt); return
    try:
        g=int(args[0]); gd=guess_games[key]; gd["tries"]+=1
        if g==gd["num"]:
            del guess_games[key]
            bot.replyMessage(Message(text=f"🎉 ĐÚNG RỒI! Số là {g}\nBạn đoán {gd['tries']} lần!"), mo, tid, tt)
        elif g<gd["num"]:
            bot.replyMessage(Message(text=f"📈 {g} nhỏ quá! Thử số lớn hơn (lần {gd['tries']})"), mo, tid, tt)
        else:
            bot.replyMessage(Message(text=f"📉 {g} lớn quá! Thử số nhỏ hơn (lần {gd['tries']})"), mo, tid, tt)
    except:
        bot.replyMessage(Message(text="❌ Nhập số hợp lệ!"), mo, tid, tt)

# ─── CARD ─────────────────────────────────────────────────────────
SUITS=["♠️ Bích","♥️ Cơ","♦️ Rô","♣️ Nhép"]
RANKS=["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
def handle_card(bot, mo, aid, tid, tt):
    name=get_user_name(bot,aid)
    card=f"{random.choice(RANKS)} {random.choice(SUITS)}"
    bot.replyMessage(Message(text=f"🃏 {name} rút được:\n\n🎴 {card}"), mo, tid, tt)

# ─── TRUTH OR DARE ────────────────────────────────────────────────
TRUTHS=["Crush của bạn là ai trong nhóm này?","Bạn đã từng nói dối ai trong nhóm chưa?",
        "Điều xấu hổ nhất bạn từng làm là gì?","Bạn có bí mật nào chưa kể với ai không?",
        "Bạn thích ai nhất trong nhóm?","Lần cuối bạn khóc là khi nào và vì sao?"]
DARES=["Nhắn tin cho crush ngay bây giờ!","Hát một bài trong 30 giây!",
       "Làm 10 cái hít đất!","Gọi điện cho người ngẫu nhiên trong danh bạ!",
       "Post ảnh selfie lên nhóm!","Kể một bí mật của bản thân!"]
def handle_truth(bot, mo, aid, tid, tt):
    bot.replyMessage(Message(text=f"💀 TRUTH:\n\n{random.choice(TRUTHS)}"), mo, tid, tt)
def handle_dare(bot, mo, aid, tid, tt):
    bot.replyMessage(Message(text=f"🎭 DARE:\n\n{random.choice(DARES)}"), mo, tid, tt)

# ─── RANDOM ──────────────────────────────────────────────────────
def handle_random(bot, mo, aid, tid, tt, args):
    try:
        lo,hi=(int(args[0]),int(args[1])) if len(args)>=2 else (1,int(args[0])) if args else (1,100)
        bot.replyMessage(Message(text=f"🎲 Số ngẫu nhiên ({lo}~{hi}): **{random.randint(lo,hi)}**"), mo, tid, tt)
    except:
        bot.replyMessage(Message(text="❌ !random [min] [max]"), mo, tid, tt)

# ─── RANK (đơn giản) ─────────────────────────────────────────────
def handle_rank(bot, mo, aid, tid, tt):
    bot.replyMessage(Message(text="🏆 Tính năng bảng xếp hạng đang phát triển!\nSắp ra mắt trong bản cập nhật tiếp theo."), mo, tid, tt)

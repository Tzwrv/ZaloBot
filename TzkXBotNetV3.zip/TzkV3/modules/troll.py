import random, time
from core import get_user_name, get_anti
from zlapi.models import Message

TROLL=[
    "👀 {name} tag tui làm gì? Tui đang nghỉ ngơi!",
    "😴 {name} ơi... tui đang ngủ mà tag gì vậy...",
    "🙄 {name} tag tui à? Tui không phải Google nha!",
    "😂 {name} nhớ tui quá rồi nên tag hả?",
    "💀 {name} muốn bị roast à? Tag tui làm chi!",
    "🤖 BEEP BOOP... {name} kích hoạt tui... BEEP BOOP... Tui lười lắm!",
    "😎 {name} dám tag bot xịn nhất group? Ngầu đó!",
    "👻 BOO! {name} làm tui giật mình rồi đó!",
    "🐸 {name} tag tui hả? Tui đang uống trà, làm phiền vậy!",
    "🎯 {name} vừa tag bot thông minh nhất! Xin chúc mừng!",
    "🌚 {name}... tag tui... ừ thì... tui đây... cần gì?",
    "😏 {name} nhớ tui không? Tui không nhớ {name} đâu nha~",
    "🔥 OI! {name} dám tag tui? Gan thật nha!",
    "💅 {name} tag tui là đúng, tui xứng đáng nhất group!",
    "🤡 {name} vừa tag bot... 10 điểm về sự dũng cảm!",
    "⚡ {name} summon tui ra đây hả? Nói đi!",
    "🦊 {name} ơi, tui không phải người giao hàng nha!",
    "🎪 {name} tag tui = tui sẽ không làm gì hết 😂",
    "🌟 {name} vừa tag ngôi sao sáng nhất group!",
    "🐧 {name} muốn xin chữ ký của bot à? 10k thôi!",
]

WAR_ATTACKS=[
    "💥 {a} UPPERCUT {t} văng ra khỏi vũ trụ!",
    "🔥 {a} triệu hồi rồng lửa thiêu {t} thành tro!",
    "⚡ {a} thả sét đánh {t} bay vèo!",
    "🗡️ {a} rút kiếm thần chém {t} một nhát!",
    "💣 {a} ném bom nguyên tử vào {t}!",
    "🥊 {a} đấm {t} bay vào mặt trăng!",
    "🐉 {a} biến thành rồng nuốt chửng {t}!",
    "🌊 {a} tạo sóng thần cuốn {t} đi mất!",
    "🎯 {a} bắn tên độc trúng {t} 100%!",
    "🔨 {a} dùng búa Thor đập {t} cái BÙNG!",
    "🌪️ {a} triệu hồi lốc xoáy cuốn {t}!",
    "☄️ {a} kéo thiên thạch rơi trúng đầu {t}!",
    "🦈 {a} thả cá mập cắn {t} không còn mảnh!",
    "🎃 {a} hoá ma ám {t} đến phát điên!",
    "💫 {a} dùng jutsu tối thượng xoá sổ {t}!",
    "🚀 {a} phóng tên lửa thẳng vào {t}!",
    "🧊 {a} đóng băng toàn bộ {t} trong 1 giây!",
]

WAR_RESULTS_WIN=["😵 {t} THUA THẢM! HP: 0/100","💀 {t} rời trận chiến vĩnh viễn!","🏳️ {t} giơ cờ trắng đầu hàng!"]
WAR_RESULTS_LOSE=["😱 {a} bị phản công! {t} THẮNG!","🔄 Trời không chấp nhận! {t} giành chiến thắng!"]

war_cd={}
def handle_war(bot, mo, aid, tid, tt, args):
    mentions=getattr(mo,"mentions",None)
    if not mentions:
        bot.replyMessage(Message(text="⚔️ Dùng: !war @người"), mo, tid, tt); return
    now=time.time(); key=f"{tid}_{aid}"
    if key in war_cd and now-war_cd[key]<15:
        bot.replyMessage(Message(text=f"⏳ Đợi {int(15-(now-war_cd[key]))}s nữa!"), mo, tid, tt); return
    war_cd[key]=now
    a=get_user_name(bot,aid); t_uid=list(mentions)[0].uid
    if str(t_uid)==str(aid):
        bot.replyMessage(Message(text="🤡 Tự war bản thân? Thiên tài!"), mo, tid, tt); return
    t=get_user_name(bot,t_uid)
    rounds=random.randint(3,5)
    log=[f"⚔️ TRẬN CHIẾN\n{a} VS {t}\n{'━'*28}"]
    for r in range(rounds):
        atk=random.choice(WAR_ATTACKS)
        if random.random()>0.35: atk=atk.replace("{a}",a).replace("{t}",t)
        else: atk=atk.replace("{a}",t).replace("{t}",a)
        log.append(f"⚡ Round {r+1}: {atk}")
    if random.random()>0.4:
        log.append(f"\n🏆 {a} THẮNG!\n"+random.choice(WAR_RESULTS_WIN).replace("{t}",t))
    else:
        log.append(f"\n🏆 {t} THẮNG!\n"+random.choice(WAR_RESULTS_LOSE).replace("{a}",a).replace("{t}",t))
    bot.replyMessage(Message(text="\n".join(log)), mo, tid, tt)

def handle_tag(bot, mo, aid, tid, tt):
    name=get_user_name(bot,aid)
    bot.replyMessage(Message(text=random.choice(TROLL).replace("{name}",name)), mo, tid, tt)

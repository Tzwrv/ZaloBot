import time, platform
from core import get_user_name, get_bot_name, get_version, get_prefix, is_admin, load_config
from zlapi.models import Message

START_TIME = time.time()

def handle_ping(bot, mo, aid, tid, tt):
    t1=time.time()
    bot.replyMessage(Message(text="🏓 Đang tính..."), mo, tid, tt)
    ms=round((time.time()-t1)*1000)
    status = "🟢 Tốt" if ms<200 else "🟡 Bình thường" if ms<500 else "🔴 Chậm"
    bot.replyMessage(Message(text=f"🏓 PONG!\n⚡ Độ trễ: {ms}ms\n📶 Trạng thái: {status}"), mo, tid, tt)

def handle_info(bot, mo, aid, tid, tt):
    u=int(time.time()-START_TIME); h,m,s=u//3600,(u%3600)//60,u%60
    cfg=load_config()
    admins=[cfg.get("admin_id","")]+cfg.get("extra_admins",[])
    text=f"""╔══════════════════════════╗
║  🤖 {get_bot_name()}
╠══════════════════════════╣
║  📦 Version : {get_version()}
║  ⚙️  Prefix  : {get_prefix()}
║  🖥️  OS      : {platform.system()} {platform.release()}
║  🐍  Python  : {platform.python_version()}
║  ⏱️  Uptime  : {h}h {m}m {s}s
║  👑  Admins  : {len(admins)} người
╠══════════════════════════╣
║  💻 Dev     : Tzk
║  📚 Library : zlapi
║  🌐 Nền tảng: Zalo Web
╚══════════════════════════╝"""
    bot.replyMessage(Message(text=text), mo, tid, tt)

def handle_uptime(bot, mo, aid, tid, tt):
    u=int(time.time()-START_TIME); h,m,s=u//3600,(u%3600)//60,u%60
    pct=min(100,int(u/3600*10))
    bar="█"*(pct//5)+"░"*(20-pct//5)
    bot.replyMessage(Message(text=f"⏱️ UPTIME\n{bar}\n🕐 {h} giờ {m} phút {s} giây"), mo, tid, tt)

def handle_my_info(bot, mo, aid, tid, tt):
    try:
        info=bot.fetchUserInfo(aid); p=info.changed_profiles.get(aid)
        name=getattr(p,"zaloName",None) or getattr(p,"displayName","N/A")
        role="👑 Admin Bot" if is_admin(aid) else "👤 Thành viên"
        text=f"""╔══════════════════════╗
║  👤 THÔNG TIN CỦA BẠN
╠══════════════════════╣
║  📛 Tên  : {name}
║  🆔 UID  : {aid}
║  🔑 Role : {role}
╚══════════════════════╝"""
        bot.replyMessage(Message(text=text), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi: {e}"), mo, tid, tt)

def handle_uid(bot, mo, aid, tid, tt):
    name=get_user_name(bot,aid)
    bot.replyMessage(Message(text=f"🆔 UID của {name}:\n{aid}"), mo, tid, tt)

def handle_group_id(bot, mo, aid, tid, tt):
    bot.replyMessage(Message(text=f"🏠 ID nhóm:\n{tid}"), mo, tid, tt)

def handle_prefix(bot, mo, aid, tid, tt):
    p=get_prefix()
    bot.replyMessage(Message(text=f"⚙️ Prefix hiện tại: {p}\nVí dụ: {p}menu, {p}ping"), mo, tid, tt)

def handle_members(bot, mo, aid, tid, tt):
    try:
        from zlapi.models import ThreadType as TT
        if tt!=TT.GROUP:
            bot.replyMessage(Message(text="❌ Chỉ dùng trong nhóm!"), mo, tid, tt); return
        gi=bot.fetchGroupInfo(tid); grid=gi.gridInfoMap.get(tid)
        members=getattr(grid,"memVerList",[]) or []
        bot.replyMessage(Message(text=f"👥 Nhóm có {len(members)} thành viên\n🆔 ID: {tid}"), mo, tid, tt)
    except Exception as e:
        bot.replyMessage(Message(text=f"❌ Lỗi: {e}"), mo, tid, tt)

def handle_list_admin(bot, mo, aid, tid, tt):
    cfg=load_config()
    main_admin=cfg.get("admin_id","Chưa set")
    extras=cfg.get("extra_admins",[])
    text=f"👑 DANH SÁCH ADMIN BOT\n{'─'*25}\n🔑 Admin chính: {main_admin}"
    if extras:
        text+="\n\n➕ Admin phụ:\n"+"\n".join(f"  • {a}" for a in extras)
    else:
        text+="\n\n(Chưa có admin phụ)"
    bot.replyMessage(Message(text=text), mo, tid, tt)

import json, os, time

CONFIG_FILE = "config.json"

def load_config():
    with open(CONFIG_FILE,"r",encoding="utf-8") as f: return json.load(f)

def save_config(d):
    with open(CONFIG_FILE,"w",encoding="utf-8") as f: json.dump(d,f,indent=2,ensure_ascii=False)

def get_prefix():    return load_config().get("prefix","!")
def get_bot_name():  return load_config().get("bot_name","Tzk X BotNet")
def get_version():   return load_config().get("version","3.0.0")

def is_admin(uid):
    cfg=load_config()
    return str(uid)==str(cfg.get("admin_id","")) or str(uid) in [str(a) for a in cfg.get("extra_admins",[])]

def add_admin(uid):
    cfg=load_config(); cfg.setdefault("extra_admins",[])
    if str(uid) not in [str(a) for a in cfg["extra_admins"]]:
        cfg["extra_admins"].append(str(uid)); save_config(cfg); return True
    return False

def remove_admin(uid):
    cfg=load_config()
    cfg["extra_admins"]=[a for a in cfg.get("extra_admins",[]) if str(a)!=str(uid)]
    save_config(cfg)

def get_anti(k):     return load_config().get("anti",{}).get(k,False)
def set_anti(k,v):
    cfg=load_config(); cfg.setdefault("anti",{}); cfg["anti"][k]=v; save_config(cfg)

def get_auto(k):     return load_config().get("auto",{}).get(k,False)

def get_user_name(bot, uid):
    try:
        info=bot.fetchUserInfo(uid); p=info.changed_profiles.get(uid)
        if p: return getattr(p,"zaloName",None) or getattr(p,"displayName",None) or f"User_{uid}"
    except: pass
    return f"User_{uid}"

def load_json(path, default=None):
    try:
        with open(path,"r",encoding="utf-8") as f: return json.load(f)
    except: return {} if default is None else default

def save_json(path, data):
    d=os.path.dirname(path)
    if d: os.makedirs(d,exist_ok=True)
    with open(path,"w",encoding="utf-8") as f: json.dump(data,f,indent=2,ensure_ascii=False)

#!/usr/bin/env python3
# ╔═══════════════════════════════════════════╗
# ║      TZK X BOTNET v3.0 - main.py         ║
# ║   Bot Zalo Chuyên Nghiệp - 70+ lệnh      ║
# ╚═══════════════════════════════════════════╝

import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from colorama import Fore, Style, init
init(autoreset=True)

from zlapi import ZaloAPI
from zlapi.models import Message, ThreadType

from core import load_config, get_prefix, is_admin, get_bot_name, get_version, get_user_name, get_anti, get_auto
from modules.menu   import handle_menu, handle_menu1, handle_menu2, handle_menu3, handle_menu4, handle_menu5
from modules.info   import handle_ping, handle_info, handle_uptime, handle_my_info, handle_uid, handle_group_id, handle_prefix, handle_members, handle_list_admin
from modules.games  import handle_taixiu, handle_xocdia, handle_boi, handle_love, handle_ship, handle_joke, handle_8ball, handle_roast, handle_guess, handle_card, handle_truth, handle_dare, handle_random, handle_rank
from modules.admin  import handle_kick, handle_mute, handle_unmute, handle_tagall, handle_addadmin, handle_rmadmin, handle_setprefix, handle_broadcast, handle_leave, handle_warn, handle_warnlist, handle_anti_status, handle_anti_toggle, is_muted, check_spam
from modules.utils  import handle_translate, handle_weather, handle_wiki, handle_qr, handle_tygia, handle_ip, handle_calc, handle_news, handle_password, handle_base64, handle_time_world, handle_textart
from modules.troll  import handle_tag, handle_war

BANNER=f"""
{Fore.CYAN}{Style.BRIGHT}
 ████████╗███████╗██╗  ██╗    ██╗  ██╗    ██████╗  ██████╗ ████████╗    ██╗   ██╗██████╗ 
    ██║   ╚══███╔╝██║ ██╔╝    ╚██╗██╔╝    ██╔══██╗██╔═══██╗╚══██╔══╝    ██║   ██║╚════██╗
    ██║     ███╔╝ █████╔╝      ╚███╔╝     ██████╔╝██║   ██║   ██║       ██║   ██║ █████╔╝
    ██║    ███╔╝  ██╔═██╗      ██╔██╗     ██╔══██╗██║   ██║   ██║       ╚██╗ ██╔╝ ╚═══██╗
    ██║   ███████╗██║  ██╗    ██╔╝ ██╗    ██████╔╝╚██████╔╝   ██║        ╚████╔╝ ██████╔╝
    ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝         ╚═══╝  ╚═════╝ 
{Fore.YELLOW}                        🤖 Tzk X BotNet v3.0 — 70+ Lệnh 🤖
{Style.RESET_ALL}"""

def log(lvl, msg):
    C={"INFO":Fore.GREEN,"ERROR":Fore.RED,"WARN":Fore.YELLOW,"LOGIN":Fore.MAGENTA,"MSG":Fore.WHITE,"DEBUG":Fore.CYAN}
    ts=time.strftime("%H:%M:%S")
    print(f"{C.get(lvl,Fore.WHITE)}{Style.BRIGHT}[{lvl}]{Style.RESET_ALL} [{ts}] {msg}")

class TzkBotV3(ZaloAPI):
    def __init__(self, imei, cookies):
        super().__init__("</>","</>",imei=imei,session_cookies=cookies)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        try:
            cfg=load_config()
            # Log
            if cfg.get("settings",{}).get("log_messages",True):
                try: name=get_user_name(self,author_id)
                except: name=str(author_id)
                log("MSG",f"{Fore.CYAN}{name}{Style.RESET_ALL}: {str(message)[:80]}")

            # Bỏ qua bot tự nhắn
            if str(author_id)==str(getattr(self,"uid","")): return

            # Kiểm tra mute
            if is_muted(author_id, thread_id): return

            if not isinstance(message,str): return
            msg=message.strip()
            p=get_prefix()

            # ── ANTI SPAM CHECK ─────────────────────────────────
            if get_anti("antispam"):
                if check_spam(author_id,thread_id):
                    self.replyMessage(Message(text=f"🚫 {get_user_name(self,author_id)} spam quá! Hãy chậm lại!"), message_object, thread_id, thread_type)
                    return

            # ── KIỂM TRA TAG BOT ─────────────────────────────────
            mentions=getattr(message_object,"mentions",None)
            bot_uid=str(getattr(self,"uid",""))
            if mentions and bot_uid:
                for m in mentions:
                    if str(m.uid)==bot_uid and cfg.get("settings",{}).get("troll_tag",True):
                        handle_tag(self,message_object,author_id,thread_id,thread_type)
                        return

            # ── PREFIX CHECK ─────────────────────────────────────
            if not msg.startswith(p): return
            parts=msg[len(p):].strip().split()
            if not parts: return
            cmd=parts[0].lower(); args=parts[1:]

            self._route(cmd,args,message_object,author_id,thread_id,thread_type)

        except Exception as e:
            log("ERROR",f"onMessage: {e}")

    def onEvent(self, event_data, event_type):
        try:
            # Welcome new member
            if get_auto("welcome"):
                self._handle_welcome(event_data, event_type)
        except: pass

    def _handle_welcome(self, event_data, event_type):
        try:
            from zlapi.models import EventType
            if str(event_type) in [str(EventType.JOIN_GROUP), "join_group"]:
                uid=getattr(event_data,"uid","") or getattr(event_data,"author_id","")
                tid=getattr(event_data,"thread_id","")
                if uid and tid:
                    name=get_user_name(self,uid)
                    bot_name=get_bot_name()
                    self.send(Message(text=f"👋 Chào mừng {name} đã tham gia nhóm!\n🤖 Tôi là {bot_name}, gõ {get_prefix()}menu để xem lệnh!"), tid, ThreadType.GROUP)
        except: pass

    def _route(self, cmd, args, mo, aid, tid, tt):
        p=get_prefix()
        routes={
            # MENU
            "menu":     lambda: handle_menu(self,mo,aid,tid,tt),
            "menu1":    lambda: handle_menu1(self,mo,aid,tid,tt),
            "menu2":    lambda: handle_menu2(self,mo,aid,tid,tt),
            "menu3":    lambda: handle_menu3(self,mo,aid,tid,tt),
            "menu4":    lambda: handle_menu4(self,mo,aid,tid,tt),
            "menu5":    lambda: handle_menu5(self,mo,aid,tid,tt),
            "help":     lambda: handle_menu(self,mo,aid,tid,tt),

            # INFO
            "ping":     lambda: handle_ping(self,mo,aid,tid,tt),
            "info":     lambda: handle_info(self,mo,aid,tid,tt),
            "bot":      lambda: handle_info(self,mo,aid,tid,tt),
            "uptime":   lambda: handle_uptime(self,mo,aid,tid,tt),
            "tôi":      lambda: handle_my_info(self,mo,aid,tid,tt),
            "me":       lambda: handle_my_info(self,mo,aid,tid,tt),
            "uid":      lambda: handle_uid(self,mo,aid,tid,tt),
            "idnhom":   lambda: handle_group_id(self,mo,aid,tid,tt),
            "groupid":  lambda: handle_group_id(self,mo,aid,tid,tt),
            "prefix":   lambda: handle_prefix(self,mo,aid,tid,tt),
            "thanhvien":lambda: handle_members(self,mo,aid,tid,tt),
            "members":  lambda: handle_members(self,mo,aid,tid,tt),
            "listadmin":lambda: handle_list_admin(self,mo,aid,tid,tt),

            # GAMES
            "taixiu":   lambda: handle_taixiu(self,mo,aid,tid,tt,args),
            "tx":       lambda: handle_taixiu(self,mo,aid,tid,tt,args),
            "xocdia":   lambda: handle_xocdia(self,mo,aid,tid,tt,args),
            "xd":       lambda: handle_xocdia(self,mo,aid,tid,tt,args),
            "boi":      lambda: handle_boi(self,mo,aid,tid,tt,args),
            "bói":      lambda: handle_boi(self,mo,aid,tid,tt,args),
            "love":     lambda: handle_love(self,mo,aid,tid,tt,args),
            "ship":     lambda: handle_ship(self,mo,aid,tid,tt,args),
            "joke":     lambda: handle_joke(self,mo,aid,tid,tt),
            "cuoi":     lambda: handle_joke(self,mo,aid,tid,tt),
            "8ball":    lambda: handle_8ball(self,mo,aid,tid,tt,args),
            "roast":    lambda: handle_roast(self,mo,aid,tid,tt,args),
            "guess":    lambda: handle_guess(self,mo,aid,tid,tt,args),
            "doansо":   lambda: handle_guess(self,mo,aid,tid,tt,args),
            "chuoiso":  lambda: handle_guess(self,mo,aid,tid,tt,args),
            "card":     lambda: handle_card(self,mo,aid,tid,tt),
            "rut":      lambda: handle_card(self,mo,aid,tid,tt),
            "truth":    lambda: handle_truth(self,mo,aid,tid,tt),
            "dare":     lambda: handle_dare(self,mo,aid,tid,tt),
            "random":   lambda: handle_random(self,mo,aid,tid,tt,args),
            "rand":     lambda: handle_random(self,mo,aid,tid,tt,args),
            "rank":     lambda: handle_rank(self,mo,aid,tid,tt),
            "war":      lambda: handle_war(self,mo,aid,tid,tt,args),

            # UTILS
            "dich":     lambda: handle_translate(self,mo,aid,tid,tt,args,"en"),
            "dichvi":   lambda: handle_translate(self,mo,aid,tid,tt,args,"vi"),
            "dichja":   lambda: handle_translate(self,mo,aid,tid,tt,args,"ja"),
            "weather":  lambda: handle_weather(self,mo,aid,tid,tt,args),
            "thoitiet": lambda: handle_weather(self,mo,aid,tid,tt,args),
            "wiki":     lambda: handle_wiki(self,mo,aid,tid,tt,args),
            "qr":       lambda: handle_qr(self,mo,aid,tid,tt,args),
            "tygia":    lambda: handle_tygia(self,mo,aid,tid,tt,args),
            "ip":       lambda: handle_ip(self,mo,aid,tid,tt,args),
            "calc":     lambda: handle_calc(self,mo,aid,tid,tt,args),
            "tính":     lambda: handle_calc(self,mo,aid,tid,tt,args),
            "news":     lambda: handle_news(self,mo,aid,tid,tt,args),
            "tintuc":   lambda: handle_news(self,mo,aid,tid,tt,args),
            "pass":     lambda: handle_password(self,mo,aid,tid,tt,args),
            "matkhau":  lambda: handle_password(self,mo,aid,tid,tt,args),
            "base64":   lambda: handle_base64(self,mo,aid,tid,tt,args),
            "time":     lambda: handle_time_world(self,mo,aid,tid,tt,args),
            "gio":      lambda: handle_time_world(self,mo,aid,tid,tt,args),
            "textart":  lambda: handle_textart(self,mo,aid,tid,tt,args),

            # ADMIN
            "kick":     lambda: handle_kick(self,mo,aid,tid,tt,args),
            "mute":     lambda: handle_mute(self,mo,aid,tid,tt,args),
            "unmute":   lambda: handle_unmute(self,mo,aid,tid,tt,args),
            "tagall":   lambda: handle_tagall(self,mo,aid,tid,tt,args),
            "tag":      lambda: handle_tagall(self,mo,aid,tid,tt,args),
            "addadmin": lambda: handle_addadmin(self,mo,aid,tid,tt,args),
            "rmadmin":  lambda: handle_rmadmin(self,mo,aid,tid,tt,args),
            "setprefix":lambda: handle_setprefix(self,mo,aid,tid,tt,args),
            "broadcast":lambda: handle_broadcast(self,mo,aid,tid,tt,args),
            "bc":       lambda: handle_broadcast(self,mo,aid,tid,tt,args),
            "leave":    lambda: handle_leave(self,mo,aid,tid,tt,args),
            "warn":     lambda: handle_warn(self,mo,aid,tid,tt,args),
            "warnlist": lambda: handle_warnlist(self,mo,aid,tid,tt),

            # ANTI
            "anti":         lambda: handle_anti_status(self,mo,aid,tid,tt),
            "antispam":     lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antispam",args),
            "antisticker":  lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antisticker",args),
            "antiphoto":    lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antiphoto",args),
            "antivideo":    lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antivideo",args),
            "antifile":     lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antifile",args),
            "antilink":     lambda: handle_anti_toggle(self,mo,aid,tid,tt,"antilink",args),
            "anticontact":  lambda: handle_anti_toggle(self,mo,aid,tid,tt,"anticontact",args),
        }

        handler=routes.get(cmd)
        if handler:
            try: handler()
            except Exception as e:
                log("ERROR",f"Lỗi lệnh '{cmd}': {e}")
                self.replyMessage(Message(text=f"❌ Lỗi: {e}"),mo,tid,tt)

# ── MAIN ──────────────────────────────────────────────────────────
def main():
    print(BANNER)
    cfg=load_config()
    imei=cfg.get("imei",""); cookies=cfg.get("session_cookies",{})

    if not imei or imei=="YOUR_IMEI_HERE":
        log("ERROR","Chưa điền IMEI trong config.json!")
        print(f"\n{Fore.YELLOW}Mở config.json và điền:\n  - imei\n  - admin_id\n  - session_cookies{Style.RESET_ALL}\n")
        input("Nhấn Enter để thoát...")
        return
    if not cookies.get("zpsid"):
        log("ERROR","Chưa điền zpsid trong session_cookies!"); return

    p=get_prefix()
    log("INFO",f"Bot: {get_bot_name()} v{get_version()}")
    log("INFO",f"Prefix: {p}  |  Admin: {cfg.get('admin_id','?')}")
    log("INFO","Đang đăng nhập Zalo...")

    import os; os.makedirs("cache",exist_ok=True)

    try:
        client=TzkBotV3(imei=imei,cookies=cookies)
        log("LOGIN","✅ Đăng nhập thành công!")
        log("INFO",f"🤖 Đang lắng nghe... Nhắn '{p}menu' trong nhóm!\n")
        client.listen(thread=True, delay=0)
    except KeyboardInterrupt:
        log("INFO","Bot đã dừng!")
    except Exception as e:
        log("ERROR",f"Lỗi khởi động: {e}")
        import traceback; traceback.print_exc()

if __name__=="__main__":
    main()
